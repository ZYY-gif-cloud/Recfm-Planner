#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <iostream>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Vector3.h>
#include <math.h>
#include <nav_msgs/Odometry.h>
#include <ros/console.h>
#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <Eigen/Eigen>
#include <random>

using namespace std;

random_device rd;
default_random_engine eng(rd());
uniform_real_distribution<double> rand_x_, rand_y_, rand_z_, rand_w_, rand_h_, rand_inf_, rand_radius1_, rand_radius2_, rand_theta_;
ros::Publisher global_map_pub_, local_map_pub1, local_map_pub2, local_map_pub3;
int polar_num_, num_circles_, seed;
double x_size_, y_size_, z_size_, start_x_, start_y_, start_z_, goal_x_, goal_y_, goal_z_, limit_z_;
double x_l_, x_h_, y_l_, y_h_, z_l_, z_h_, w_l_, w_h_, h_l_, h_h_, radius_l_, radius_h_, theta_, init_radius_;
double resolution_, refresh_rate_;
sensor_msgs::PointCloud2 global_pcd_;
sensor_msgs::PointCloud2 local_pcd_type1;
sensor_msgs::PointCloud2 local_pcd_type2;
sensor_msgs::PointCloud2 local_pcd_type3;
pcl::PointCloud<pcl::PointXYZ> global_cloud_;
pcl::PointCloud<pcl::PointXYZ> local_cloud_type1;
pcl::PointCloud<pcl::PointXYZ> local_cloud_type2;
pcl::PointCloud<pcl::PointXYZ> local_cloud_type3;

void RandomMapGenerate()
{
  pcl::PointXYZ pt_random;
  vector<Eigen::Vector2d> obs_position;

  rand_x_ = uniform_real_distribution<double>(x_l_, x_h_);
  rand_y_ = uniform_real_distribution<double>(y_l_, y_h_);
  rand_z_ = uniform_real_distribution<double>(z_l_, z_h_);
  rand_w_ = uniform_real_distribution<double>(w_l_, w_h_);
  rand_h_ = uniform_real_distribution<double>(h_l_, h_h_);
  rand_radius1_ = uniform_real_distribution<double>(radius_l_, radius_h_);
  rand_radius2_ = uniform_real_distribution<double>(radius_l_, radius_h_);
  rand_theta_ = uniform_real_distribution<double>(-theta_, theta_);

  for (int i = 0; i < polar_num_ / 2; i++)
  {
    double x, y, w, h;
    x = rand_x_(eng);
    y = rand_y_(eng);
    w = rand_w_(eng);

    x = floor(x / resolution_) * resolution_ + resolution_ / 2.0;
    y = floor(y / resolution_) * resolution_ + resolution_ / 2.0;

    if ((Eigen::Vector2d(x, y) - Eigen::Vector2d(goal_x_, goal_y_)).norm() <= 1.2 * (init_radius_ + w / 2) ||
        (Eigen::Vector2d(x, y) - Eigen::Vector2d(start_x_, start_y_)).norm() <= 1.2 * (init_radius_ + w / 2))
    {
      i--;
      continue;
    }

    int num_w = ceil(w / resolution_);
    h = rand_h_(eng);
    h = std::min(h, limit_z_);
    int num_h = ceil(h / resolution_);

    for (int r = -num_w / 2.0; r < num_w / 2.0; r++)
      for (int s = -num_w / 2.0; s < num_w / 2.0; s++)
        for (int t = -20; t < num_h; t++)
        {
          pt_random.x = x + (r + 0.5) * resolution_ + 1e-2;
          pt_random.y = y + (s + 0.5) * resolution_ + 1e-2;
          pt_random.z = (t + 0.5) * resolution_ + 1e-2;

          if ((Eigen::Vector2d(pt_random.x, pt_random.y) - Eigen::Vector2d(goal_x_, goal_y_)).norm() > init_radius_ &&
              (Eigen::Vector2d(pt_random.x, pt_random.y) - Eigen::Vector2d(start_x_, start_y_)).norm() > init_radius_)
          {
            global_cloud_.points.push_back(pt_random);
            local_cloud_type1.points.push_back(pt_random);
          }
        }
  }

  for (int i = 0; i < polar_num_ / 2; i++)
  {
    double x, y, w, h;
    x = rand_x_(eng);
    y = rand_y_(eng);
    w = rand_w_(eng);

    x = floor(x / resolution_) * resolution_ + resolution_ / 2.0;
    y = floor(y / resolution_) * resolution_ + resolution_ / 2.0;

    if ((Eigen::Vector2d(x, y) - Eigen::Vector2d(goal_x_, goal_y_)).norm() <= 1.2 * (init_radius_ + w / 2) ||
        (Eigen::Vector2d(x, y) - Eigen::Vector2d(start_x_, start_y_)).norm() <= 1.2 * (init_radius_ + w / 2))
    {
      i--;
      continue;
    }

    obs_position.push_back(Eigen::Vector2d(x, y));

    int num_w = ceil(w / resolution_);
    double radius = w / 2;
    h = rand_h_(eng);
    h = std::min(h, limit_z_);
    int num_h = ceil(h / resolution_);

    for (int r = -num_w / 2.0; r < num_w / 2.0; r++)
      for (int s = -num_w / 2.0; s < num_w / 2.0; s++)
        for (int t = -20; t < num_h; t++)
        {
          pt_random.x = x + (r + 0.5) * resolution_ + 1e-2;
          pt_random.y = y + (s + 0.5) * resolution_ + 1e-2;
          pt_random.z = (t + 0.5) * resolution_ + 1e-2;

          if ((Eigen::Vector2d(pt_random.x, pt_random.y) - Eigen::Vector2d(goal_x_, goal_y_)).norm() > init_radius_ &&
              (Eigen::Vector2d(pt_random.x, pt_random.y) - Eigen::Vector2d(start_x_, start_y_)).norm() > init_radius_)
          {
            if ((Eigen::Vector2d(pt_random.x, pt_random.y) - Eigen::Vector2d(x, y)).norm() <= radius)
            {
              global_cloud_.points.push_back(pt_random);
              local_cloud_type2.points.push_back(pt_random);
            }
          }
        }
  }

  for (int i = 0; i < num_circles_; i++)
  {
    double x, y, z, radius1, radius2, theta;
    x = rand_x_(eng);
    y = rand_y_(eng);
    z = rand_z_(eng);
    radius1 = rand_radius1_(eng);
    radius2 = rand_radius2_(eng);
    theta = rand_theta_(eng);

    x = floor(x / resolution_) * resolution_ + resolution_ / 2.0;
    y = floor(y / resolution_) * resolution_ + resolution_ / 2.0;
    z = floor(z / resolution_) * resolution_ + resolution_ / 2.0;

    if ((Eigen::Vector3d(x, y, z) - Eigen::Vector3d(goal_x_, goal_y_, goal_z_)).norm() <= 1.2 * (init_radius_ + std::max(radius1, radius2)) ||
        (Eigen::Vector3d(x, y, z) - Eigen::Vector3d(start_x_, start_y_, start_z_)).norm() <= 1.2 * (init_radius_ + std::max(radius1, radius2)))
    {
      i--;
      continue;
    }

    Eigen::Vector3d translate(x, y, z);
    Eigen::Matrix3d rotate;
    rotate << cos(theta), -sin(theta), 0.0,
        sin(theta), cos(theta), 0.0,
        0, 0, 1;

    Eigen::Vector3d cpt;
    for (double angle = 0.0; angle < M_PI * 2; angle += resolution_ / 2)
    {
      cpt(0) = 0.0;
      cpt(1) = radius1 * cos(angle);
      cpt(2) = radius2 * sin(angle);

      Eigen::Vector3d cpt_if;
      for (int ifx = -0; ifx <= 0; ifx++)
        for (int ify = -0; ify <= 0; ify++)
          for (int ifz = -0; ifz <= 0; ifz++)
          {
            cpt_if = cpt + Eigen::Vector3d(ifx * resolution_, ify * resolution_, ifz * resolution_);
            cpt_if = rotate * cpt_if + translate;

            if ((cpt_if - Eigen::Vector3d(goal_x_, goal_y_, goal_z_)).norm() > init_radius_ &&
                (cpt_if - Eigen::Vector3d(start_x_, start_y_, start_z_)).norm() > init_radius_)
            {
              pt_random.x = cpt_if(0);
              pt_random.y = cpt_if(1);
              pt_random.z = cpt_if(2);
              global_cloud_.points.push_back(pt_random);
              local_cloud_type3.points.push_back(pt_random);
            }
          }
    }
  }

  ROS_WARN("Finished generate fixed map");
}

void pubSensedPoints()
{
  pcl::toROSMsg(global_cloud_, global_pcd_);
  pcl::toROSMsg(local_cloud_type1, local_pcd_type1);
  pcl::toROSMsg(local_cloud_type2, local_pcd_type2);
  pcl::toROSMsg(local_cloud_type3, local_pcd_type3);

  global_pcd_.header.frame_id = "world";
  local_pcd_type1.header.frame_id = "world";
  local_pcd_type2.header.frame_id = "world";
  local_pcd_type3.header.frame_id = "world";

  global_map_pub_.publish(global_pcd_);
  local_map_pub1.publish(local_pcd_type1);
  local_map_pub2.publish(local_pcd_type2);
  local_map_pub3.publish(local_pcd_type3);
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "random_forest");
  ros::NodeHandle n("~");

  global_map_pub_ = n.advertise<sensor_msgs::PointCloud2>("/map_generator/global_cloud", 1);
  local_map_pub1 = n.advertise<sensor_msgs::PointCloud2>("/map_generator/local_cloud/type1", 1);
  local_map_pub2 = n.advertise<sensor_msgs::PointCloud2>("/map_generator/local_cloud/type2", 1);
  local_map_pub3 = n.advertise<sensor_msgs::PointCloud2>("/map_generator/local_cloud/type3", 1);

  n.param("map/x_size", x_size_, 50.0);
  n.param("map/y_size", y_size_, 50.0);
  n.param("map/z_size", z_size_, 6.0);
  n.param("map/resolution", resolution_, 0.1);
  n.param("map/rate", refresh_rate_, 10.0);
  n.param("map/seed", seed, 0);

  n.param("start_x", start_x_, 0.0);
  n.param("start_y", start_y_, 0.0);
  n.param("start_z", start_z_, 0.0);
  n.param("goal_x", goal_x_, 0.0);
  n.param("goal_y", goal_y_, 0.0);
  n.param("goal_z", goal_z_, 0.0);
  n.param("init_radius", init_radius_, 3.0);

  n.param("map/polar_num", polar_num_, 30);
  n.param("ObstacleShape/lower_rad", w_l_, 0.3);
  n.param("ObstacleShape/upper_rad", w_h_, 0.8);
  n.param("ObstacleShape/lower_hei", h_l_, 3.0);
  n.param("ObstacleShape/upper_hei", h_h_, 7.0);

  n.param("map/circle_num", num_circles_, 30);
  n.param("ObstacleShape/radius_l", radius_l_, 6.0);
  n.param("ObstacleShape/radius_h", radius_h_, 7.0);
  n.param("ObstacleShape/z_l", z_l_, 6.0);
  n.param("ObstacleShape/z_h", z_h_, 7.0);
  n.param("ObstacleShape/theta", theta_, 0.5);

  x_l_ = -x_size_ / 2.0;
  x_h_ = +x_size_ / 2.0;
  y_l_ = -y_size_ / 2.0;
  y_h_ = +y_size_ / 2.0;
  limit_z_ = z_size_;

  ros::Duration(0.5).sleep();

  if (seed != 0)
    eng.seed(seed);

  RandomMapGenerate();

  ros::Rate loop_rate(refresh_rate_);
  while (ros::ok())
  {
    pubSensedPoints();
    ros::spinOnce();
    loop_rate.sleep();
  }
}
