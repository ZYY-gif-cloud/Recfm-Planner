#include <recfm_path_searching/rrt.h>

RRT::~RRT()
{
    kd_free(kdtree_);
    for (int i = 0; i < max_tree_node_num_; i++)
    {
        delete path_node_pool_[i];
    }
}

Eigen::Vector3d RRT::getRandomNode()
{
    std::random_device rd;
    std::mt19937_64 gen(rd());
    std::uniform_real_distribution<double> dis(0, 1);
    Eigen::Vector3i x_idx;
    x_idx(0) = std::floor(dis(gen) * POOL_SIZE_(0) + 0.5);
    x_idx(1) = std::floor(dis(gen) * POOL_SIZE_(1) + 0.5);
    x_idx(2) = std::floor(dis(gen) * POOL_SIZE_(2) + 0.5);
    Eigen::Vector3d x_rand;
    x_rand = Index2Coord(x_idx);
    return x_rand;
}

inline Eigen::Vector3d RRT::Index2Coord(const Eigen::Vector3i &index) const 
{
    return ((index - CENTER_IDX_).cast<double>() * step_size_) + center_;
};

Eigen::Vector3d RRT::Step(Eigen::Vector3d from, Eigen::Vector3d to, double step_length)
{
    Eigen::Vector3d step_dir = to - from;
    if (step_dir.norm() <= step_length)
        return to;
    step_dir.normalize();
    Eigen::Vector3d x_new = from + step_length * step_dir;
    return x_new;
}

bool RRT::isCollisionFree(Eigen::Vector3d from, Eigen::Vector3d to, double map_resolution)
{
    Eigen::Vector3d step_dir = to - from;
    step_dir.normalize();
    for (double t = 0; t < step_dir.norm(); t += map_resolution)
    {
        Eigen::Vector3d x_test = from + t * step_dir;
        if (grid_map_->getInflateOccupancy(x_test))
            return false;
    }
    return true;
}

void RRT::retrievePath(RRTPathNodePtr end_node, std::vector<Eigen::Vector3d>& path)
{
    RRTPathNodePtr node = end_node;
    while (node->parent != NULL)
    {
        path.push_back(node->position);
        node = node->parent;
    }
    path.push_back(node->position);
    std::reverse(path.begin(), path.end());
}

void RRT::setParam(ros::NodeHandle& nh)
{
    nh.param("rrt/max_tree_node_num", max_tree_node_num_, 100000);
    nh.param("rrt/step_length", step_length_, 0.5);
    nh.param("rrt/max_allowed_time", max_allowed_time_, 0.01);
    nh.param("rrt/search_radius", search_radius_, 0.5);
    nh.param("rrt/collision_check_resolution", resolution_, 0.05);
    nh.param("rrt/goalBiasProbability", goalBiasProbability_, 0.8);
}

void RRT::initGridMap(GridMap::Ptr occ_map, const Eigen::Vector3i pool_size, const double step_size)
{
    step_size_ = step_size;
    POOL_SIZE_ = pool_size;
    CENTER_IDX_ = pool_size / 2;
    grid_map_ = occ_map;
    kdtree_ = kd_create(3);
    use_node_num_ = 0;
    path_node_pool_.resize(max_tree_node_num_);
    for (int i = 0; i < max_tree_node_num_; i++)
    {
        path_node_pool_[i] = new RRTPathNode();
    }
}

void RRT::getWholeTree(std::vector<Eigen::Vector3d>& vertices, std::vector<std::pair<Eigen::Vector3d, Eigen::Vector3d>>& edges)
{
    RRTPathNodePtr start_node = path_node_pool_[0];
    vertices.push_back(start_node->position);

    std::queue<RRTPathNodePtr> bfs_queue;
    bfs_queue.push(start_node);
    while (!bfs_queue.empty())
    {
        RRTPathNodePtr curr_node = bfs_queue.front();
        bfs_queue.pop();
        if (curr_node->children.empty())
            continue;
        for (RRTPathNodePtr child : curr_node->children)
        {
            assert(std::find(child->children.begin(), child->children.end(), curr_node) == child->children.end());
            vertices.push_back(child->position);
            edges.push_back(std::make_pair(curr_node->position, child->position));
            bfs_queue.push(child);
        }
    }
}

bool RRT::search(Eigen::Vector3d start_pt, Eigen::Vector3d end_pt, std::vector<Eigen::Vector3d>& path)
{
    center_ = (start_pt + end_pt) / 2;
    use_node_num_ = 0;
    kd_clear(kdtree_);
    for (int i = 0; i < max_tree_node_num_; i++)
    {
        RRTPathNodePtr node = path_node_pool_[i];
        node->children.clear();
        node->parent = NULL;
        node->g_cost = inf;
    }

    ros::Time start_time = ros::Time::now();
    RRTPathNodePtr start_node = path_node_pool_[use_node_num_];
    start_node->position = start_pt;
    start_node->g_cost = 0;
    start_node->parent = NULL;
    use_node_num_++;
    kd_insert(kdtree_, start_node->position.data(), start_node);

    for (int i = 0; i < max_tree_node_num_; i++)
    {
        ros::Time current_time = ros::Time::now();
        if ((current_time - start_time).toSec() > max_allowed_time_)
        {
            std::cout << "reach max allowed time" << std::endl;
            return false;
        }

        std::random_device rd;
        std::mt19937_64 gen(rd());
        std::uniform_real_distribution<double> dis(0, 1);
        Eigen::Vector3d x_rand;

        if (dis(gen) < goalBiasProbability_)
        {
            x_rand = end_pt;
        }
        else 
        {
            x_rand = getRandomNode();
        }

        kdres* nearest_tree_node = kd_nearest(kdtree_, x_rand.data());
        RRTPathNodePtr nearest_node = static_cast<RRTPathNode*>(kd_res_item_data(nearest_tree_node));
        kd_res_free(nearest_tree_node);
        Eigen::Vector3d x_near = nearest_node->position;
        Eigen::Vector3d x_new = Step(x_near, x_rand, step_length_);
        if (isCollisionFree(x_near, x_new, resolution_))
        {
            RRTPathNodePtr x_new_node = path_node_pool_[use_node_num_];
            x_new_node->position = x_new;
            x_new_node->g_cost = nearest_node->g_cost + (x_new - x_near).norm();
            x_new_node->parent = nearest_node;
            nearest_node->children.push_back(x_new_node);
            kd_insert(kdtree_, x_new.data(), x_new_node);
            use_node_num_++;

            if ((x_new - end_pt).norm() < search_radius_)
            {
                if (isCollisionFree(x_new, end_pt, resolution_))
                {
                    RRTPathNodePtr end_node = path_node_pool_[use_node_num_];
                    use_node_num_++;
                    end_node->position = end_pt;
                    end_node->g_cost = x_new_node->g_cost + (end_pt - x_new).norm();
                    end_node->parent = x_new_node;
                    x_new_node->children.push_back(end_node);

                    std::cout << "reach end point" << std::endl;
                    retrievePath(end_node, path);
                    ros::Time end_time = ros::Time::now();
                    double total_time = (end_time - start_time).toSec();
                    double total_cost = end_node->g_cost;
                    std::cout << "total cost: " << total_cost << std::endl;
                    std::cout << "total time: " << total_time << std::endl;
                    return true;
                }
            }
        }
    }
    std::cout << "tree is full, no path found" << std::endl;
    return false;
}







