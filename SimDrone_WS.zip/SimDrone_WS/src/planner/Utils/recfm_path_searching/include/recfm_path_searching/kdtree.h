#ifndef _KDTREE_H_
#define _KDTREE_H_

#ifdef __cplusplus
extern "C" {
#endif

struct kdhyperrect {
    int dim;
    double *min, *max;
};

struct kdnode {
    double *pos;
    int dir;
    void *data;
    struct kdnode *left, *right;
};

struct res_node {
    struct kdnode *item;
    double dist_sq;
    struct res_node *next;
};

struct kdtree {
    int dim;
    struct kdnode *root;
    struct kdhyperrect *rect;
    void (*destr)(void*);
};

struct kdres {
    struct kdtree *tree;
    struct res_node *rlist, *riter;
    int size;
};

struct kdtree *kd_create(int k);
void kd_free(struct kdtree *tree);
void kd_clear(struct kdtree *tree);
void kd_data_destructor(struct kdtree *tree, void (*destr)(void*));
int kd_insert(struct kdtree *tree, const double *pos, void *data);
struct kdres *kd_nearest(struct kdtree *tree, const double *pos);
struct kdres *kd_nearest_range(struct kdtree *tree, const double *pos, double range);
void kd_res_free(struct kdres *set);
int kd_res_size(struct kdres *set);
void kd_res_rewind(struct kdres *set);
int kd_res_end(struct kdres *set);
int kd_res_next(struct kdres *set);
void *kd_res_item(struct kdres *set, double *pos);
void *kd_res_item_data(struct kdres *set);

#ifdef __cplusplus
}
#endif

#endif

