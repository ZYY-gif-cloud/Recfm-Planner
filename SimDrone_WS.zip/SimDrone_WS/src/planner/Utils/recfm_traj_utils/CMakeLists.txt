cmake_minimum_required(VERSION 2.8.3)
project(recfm_traj_utils)
set(CMAKE_BUILD_TYPE "Release")
set(CMAKE_CXX_FLAGS "-std=c++11")
set(CMAKE_CXX_FLAGS_RELEASE "-O3 -Wall -g")
find_package(Eigen3 REQUIRED)
find_package(PCL 1.7 REQUIRED)
find_package(catkin REQUIRED COMPONENTS
  roscpp
  std_msgs
  cv_bridge
)
catkin_package(
  INCLUDE_DIRS include
  LIBRARIES recfm_traj_utils
  CATKIN_DEPENDS roscpp std_msgs
)
include_directories(
  SYSTEM
  include
  ${catkin_INCLUDE_DIRS}
  ${Eigen3_INCLUDE_DIRS}
  ${PCL_INCLUDE_DIRS}
)
add_library(recfm_traj_utils src/planning_visualization.cpp src/polynomial_traj.cpp)
target_link_libraries(recfm_traj_utils ${catkin_LIBRARIES} ${PCL_LIBRARIES} ${Eigen3_LIBRARIES})


