#ifndef _REBO_REPLAN_FSM_H_
#define _REBO_REPLAN_FSM_H_

#include <Eigen/Eigen>
#include <algorithm>
#include <iostream>
#include <nav_msgs/Path.h>
#include <sensor_msgs/Imu.h>
#include <ros/ros.h>
#include <std_msgs/Empty.h>
#include <vector>
#include <visualization_msgs/Marker.h>
#include <recfm_bspline_opt/bspline_optimizer.h>
#include <recfm_plan_env/grid_map.h>
#include <recfm_planner/Bspline.h>
#include <recfm_planner/planner_manager.h>
#include <recfm_traj_utils/planning_visualization.h>

using std::vector;

namespace recfm_planner
{
class ReCFMReplanFSM
{
private:
  enum FSM_EXEC_STATE
  {
    INIT,
    WAIT_TARGET,
    GEN_NEW_TRAJ,
    REPLAN_TRAJ,
    EXEC_TRAJ,
    EMERGENCY_STOP
  };

  enum TARGET_TYPE
  {
    MANUAL_TARGET = 1,
    PRESET_TARGET = 2,
    REFENCE_PATH = 3
  };

  ReCFMPlannerManager::Ptr planner_manager_;
  PlanningVisualization::Ptr visualization_;

  int target_type_;
  double no_replan_thresh_, replan_thresh_;
  double waypoints_[50][3];
  int waypoint_num_;
  double planning_horizen_, planning_horizen_time_;
  double emergency_time_;

  bool trigger_;
  bool have_target_;
  bool have_odom_;
  bool have_new_target_;
  FSM_EXEC_STATE exec_state_;
  int continously_called_times_{0};

  Eigen::Vector3d odom_pos_, odom_vel_, odom_acc_;
  Eigen::Quaterniond odom_orient_;

  Eigen::Vector3d init_pt_, start_pt_, start_vel_, start_acc_, start_yaw_;
  Eigen::Vector3d end_pt_, end_vel_;
  Eigen::Vector3d local_target_pt_, local_target_vel_, local_target_acc_;
  int current_wp_;

  bool flag_escape_emergency_;

  ros::NodeHandle node_;
  ros::Timer exec_timer_, safety_timer_;
  ros::Subscriber waypoint_sub_, odom_sub_;
  ros::Publisher replan_pub_, new_pub_, bspline_pub_, data_disp_pub_;

  bool callReboundReplan(bool flag_use_poly_init, bool flag_randomPolyTraj);
  bool callEmergencyStop(Eigen::Vector3d stop_pos);
  bool planFromCurrentTraj();

  void changeFSMExecState(FSM_EXEC_STATE new_state, string pos_call);
  std::pair<int, ReCFMReplanFSM::FSM_EXEC_STATE> timesOfConsecutiveStateCalls();
  void printFSMExecState();

  void planGlobalTrajbyGivenWps();
  void getLocalTarget();

  void execFSMCallback(const ros::TimerEvent &e);
  void checkCollisionCallback(const ros::TimerEvent &e);
  void waypointCallback(const nav_msgs::PathConstPtr &msg);
  void odometryCallback(const nav_msgs::OdometryConstPtr &msg);

  bool checkCollision();

public:
  ReCFMReplanFSM() {}
  ~ReCFMReplanFSM() {}
  void init(ros::NodeHandle &nh);
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};

} // namespace recfm_planner

#endif
