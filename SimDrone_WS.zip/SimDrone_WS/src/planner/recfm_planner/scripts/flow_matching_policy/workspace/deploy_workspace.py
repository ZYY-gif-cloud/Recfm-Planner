import os
import hydra
import torch
import copy
import random
import numpy as np
import time
from pathlib import Path

from omegaconf import OmegaConf
from torch.utils.data import DataLoader
from termcolor import cprint
from torch.nn import functional as F

from flow_matching_policy.workspace.base_workspace import BaseWorkspace
from flow_matching_policy.common.pytorch_util import dict_apply

OmegaConf.register_new_resolver("eval", eval, replace=True)


class CFMWorkspace(BaseWorkspace):
    def __init__(self, cfg: OmegaConf, output_dir=None):
        super().__init__(cfg, output_dir=output_dir)

        seed = cfg.deploying.seed
        torch.manual_seed(seed)
        np.random.seed(seed)
        random.seed(seed)

        model = hydra.utils.instantiate(cfg.policy)

        if cfg.deploying.use_ema:
            ema_model = copy.deepcopy(model)

        self.model = model
        self.ema_model = ema_model if cfg.deploying.use_ema else None
        self.device = torch.device(cfg.deploying.device)

        exclude_keys = ("optimizer", "lr_scheduler", "policy")
        self.load_checkpoint(
            path=Path(__file__).resolve().parents[2] / cfg.policy.ckpt_path,
            exclude_keys=exclude_keys,
            include_keys=None,
        )

        self.model.to(self.device)
        if self.ema_model is not None:
            self.ema_model.to(self.device)

        self.policy = self.model
        if cfg.deploying.use_ema:
            self.policy = self.ema_model
        self.policy.eval()

    def run(self, batch):
        with torch.no_grad():
            batch = dict_apply(
                batch,
                lambda x: x.to(self.device, non_blocking=True)
                if isinstance(x, torch.Tensor)
                else x,
            )
            pred_action = self.policy.predict_action(batch)
            return pred_action







































































































        
       
        

