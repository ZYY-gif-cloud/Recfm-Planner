#ifndef RRT_H_
#define RRT_H_
#include <Eigen/Eigen>
#include <ros/ros.h>
#include <random>
#include <queue>
#include <recfm_plan_env/grid_map.h>
#include <recfm_path_searching/kdtree.h>

using namespace std;
using namespace Eigen;

#define inf (1 << 30);

class RRTPathNode  
{
public:
  Eigen::Vector3d position;
  Eigen::Vector3d velocity;
  Eigen::Vector3d acceleration;
  double duration;
  RRTPathNode* parent = NULL;
  std::vector<RRTPathNode*> children;
  RRTPathNode(){}
  ~RRTPathNode(){}
};  
typedef RRTPathNode* RRTPathNodePtr;

class KinoRRT  
{
private:
  kdtree* kdtree_;
  std::vector<RRTPathNodePtr> path_node_pool_;
  GridMap::Ptr grid_map_;
  int max_tree_node_num_;
  int use_node_num_;
  double max_allowed_time_;
  double goal_tolerance_;
  Eigen::Vector3i CENTER_IDX_, POOL_SIZE_;
  Eigen::Vector3d center_;
  double step_size_;
  double max_vel_;
  double max_acc_;
  double max_sample_duration_;
  double delta_duration_;
  double acc_res_;
  double vel_res_;
  double goalBiasProbability_;
  std::vector<RRTPathNodePtr> path_pool_;
  vector<double> times_;

  Eigen::Vector3d getRandomNode();
  inline Eigen::Vector3d Index2Coord(const Eigen::Vector3i &index) const;
  void StateTransit(Eigen::Matrix<double, 6, 1>& x0, Eigen::Matrix<double, 6, 1>& xt, Eigen::Vector3d ut, double t);
  void Step(Eigen::Vector3d from_pt, Eigen::Vector3d from_vel, Eigen::Vector3d &to_pt, Eigen::Vector3d &to_vel, Eigen::Vector3d &ut, double &sample_duration);
  void Step(Eigen::Vector3d from_pt, Eigen::Vector3d from_vel, Eigen::Vector3d to_pt, RRTPathNodePtr &nearest_node);
  std::vector<RRTPathNodePtr> retrievePath(RRTPathNodePtr end_node);

public:
  typedef std::shared_ptr<KinoRRT> Ptr;
  KinoRRT() {};
  ~KinoRRT();
  void setParam(ros::NodeHandle& nh);
  void initGridMap(GridMap::Ptr occ_map, const Eigen::Vector3i pool_size, const double step_size );
  bool RRTsearch(Eigen::Vector3d start_pt, Eigen::Vector3d start_vel, Eigen::Vector3d start_acc, Eigen::Vector3d end_pt, Eigen::Vector3d end_vel);
  std::vector<std::vector<Eigen::Vector3d>> sampleCombinePath();
  std::vector<Eigen::Vector3d> samplePath();
  void getWholeTree(std::vector<Eigen::Vector3d>& vertices, std::vector<std::pair<Eigen::Vector3d, Eigen::Vector3d>>& edges);
  Eigen::Vector3d evaluate(double t) ;
  Eigen::Vector3d evaluateVel(double t) ;
  Eigen::Vector3d evaluateAcc(double t) ;
}; 
#endif
