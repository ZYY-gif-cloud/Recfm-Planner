project(recfm_planner)
set(CMAKE_BUILD_TYPE "Release")
ADD_COMPILE_OPTIONS(-std=c++11)
ADD_COMPILE_OPTIONS(-std=c++14)
set(CMAKE_CXX_FLAGS_RELEASE "-O3 -Wall -g")

find_package(Eigen3 REQUIRED)
find_package(PCL 1.7 REQUIRED)
find_package(catkin REQUIRED COMPONENTS
  roscpp
  std_msgs
  geometry_msgs
  quadrotor_msgs
  recfm_plan_env
  recfm_path_searching
  recfm_bspline_opt
  recfm_traj_utils
  message_generation
  cv_bridge
  sensor_msgs
  roslib
)

add_message_files(
  FILES
  Bspline.msg
  Trajectory.msg
)

add_service_files(
  FILES
  Planner.srv
)

generate_messages(
  DEPENDENCIES
  std_msgs
  geometry_msgs
  sensor_msgs
)

catkin_package(
  INCLUDE_DIRS include
  LIBRARIES recfm_planner
  CATKIN_DEPENDS recfm_plan_env recfm_path_searching recfm_bspline_opt recfm_traj_utils std_msgs message_runtime
)

include_directories(
  include
  SYSTEM
  ${catkin_INCLUDE_DIRS}
  ${PROJECT_SOURCE_DIR}/include
  ${EIGEN3_INCLUDE_DIR}
  ${PCL_INCLUDE_DIRS}
)

add_executable(recfm_planner_node
  src/recfm_planner_node.cpp
  src/recfm_replan_fsm.cpp
  src/planner_manager.cpp
)
target_link_libraries(recfm_planner_node ${catkin_LIBRARIES} ${EIGEN3_LIBRARIES} ${PCL_LIBRARIES})
add_dependencies(recfm_planner_node ${${PROJECT_NAME}_EXPORTED_TARGETS})

add_executable(recfm_traj_server src/traj_server.cpp)
target_link_libraries(recfm_traj_server ${catkin_LIBRARIES} ${EIGEN3_LIBRARIES} ${PCL_LIBRARIES})
add_dependencies(recfm_traj_server ${${PROJECT_NAME}_EXPORTED_TARGETS})

catkin_install_python(PROGRAMS scripts/planner_server.py DESTINATION ${CATKIN_PACKAGE_BIN_DESTINATION})
