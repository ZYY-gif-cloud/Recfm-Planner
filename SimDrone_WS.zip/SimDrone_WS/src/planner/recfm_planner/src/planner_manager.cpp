#include <recfm_planner/planner_manager.h>
#include <thread>

namespace recfm_planner
{
ReCFMPlannerManager::ReCFMPlannerManager() {}
ReCFMPlannerManager::~ReCFMPlannerManager() { std::cout << "des manager" << std::endl; }

void ReCFMPlannerManager::updateTrajInfo(const UniformBspline &position_traj, const ros::Time time_now)
{
    local_data_.start_time_ = time_now;
    local_data_.position_traj_ = position_traj;
    local_data_.velocity_traj_ = local_data_.position_traj_.getDerivative();
    local_data_.acceleration_traj_ = local_data_.velocity_traj_.getDerivative();
    local_data_.start_pos_ = local_data_.position_traj_.evaluateDeBoorT(0.0);
    local_data_.duration_ = local_data_.position_traj_.getTimeSum();
    local_data_.traj_id_ += 1;
}

void ReCFMPlannerManager::reparamBspline(UniformBspline &bspline, vector<Eigen::Vector3d> &start_end_derivative, double ratio, Eigen::MatrixXd &ctrl_pts, double &dt, double &time_inc)
{
  double time_origin = bspline.getTimeSum();
  int seg_num = bspline.getControlPoint().cols() - 3;
  bspline.lengthenTime(ratio);
  double duration = bspline.getTimeSum();
  dt = duration / double(seg_num);
  time_inc = duration - time_origin;
  vector<Eigen::Vector3d> point_set;
  for (double time = 0.0; time <= duration + 1e-4; time += dt)
  {
    point_set.push_back(bspline.evaluateDeBoorT(time));
  }
  UniformBspline::parameterizeToBspline(dt, point_set, start_end_derivative, ctrl_pts);
}

bool ReCFMPlannerManager::refineTrajAlgo(UniformBspline &traj, vector<Eigen::Vector3d> &start_end_derivative, double ratio, double &ts, Eigen::MatrixXd &optimal_control_points)
{
    double t_inc;
    Eigen::MatrixXd ctrl_pts;
    reparamBspline(traj, start_end_derivative, ratio, ctrl_pts, ts, t_inc);
    traj = UniformBspline(ctrl_pts, 3, ts);
    double t_step = traj.getTimeSum() / (ctrl_pts.cols() - 3);
    bspline_optimizer_rebound_->ref_pts_.clear();
    for (double t = 0; t < traj.getTimeSum() + 1e-4; t += t_step)
        bspline_optimizer_rebound_->ref_pts_.push_back(traj.evaluateDeBoorT(t));
    bool success = bspline_optimizer_rebound_->BsplineOptimizeTrajRefine(ctrl_pts, ts, optimal_control_points);
    return success;
}

bool ReCFMPlannerManager::optimizeTrajAlgo(UniformBspline &traj, vector<Eigen::Vector3d> &start_end_derivative, double ratio, double &ts, Eigen::MatrixXd &optimal_control_points)
{
    double t_inc;
    Eigen::MatrixXd ctrl_pts;
    reparamBspline(traj, start_end_derivative, ratio, ctrl_pts, ts, t_inc);
    vector<vector<Eigen::Vector3d>> a_star_pathes;
    a_star_pathes = bspline_optimizer_rebound_->initControlPoints(ctrl_pts, true);
    traj = UniformBspline(ctrl_pts, 3, ts);
    bool success = bspline_optimizer_rebound_->BsplineOptimizeTraj(ctrl_pts, ts, optimal_control_points);
    return success;
}

void ReCFMPlannerManager::initPlanModules(ros::NodeHandle &nh, PlanningVisualization::Ptr vis)
{
    nh.param("manager/max_vel", pp_.max_vel_, -1.0);
    nh.param("manager/max_acc", pp_.max_acc_, -1.0);
    nh.param("manager/max_jerk", pp_.max_jerk_, -1.0);
    nh.param("manager/feasibility_tolerance", pp_.feasibility_tolerance_, 0.0);
    nh.param("manager/control_points_distance", pp_.ctrl_pt_dist, -1.0);
    nh.param("manager/planning_horizon", pp_.planning_horizen_, 5.0);
    nh.param("manager/planning_collection", planning_collection_, false);
    nh.param("manager/planning_optimiaztion", planning_optimiaztion_, false);
    nh.param("manager/trajectory_num", trajectory_num_, 10);
    nh.param("manager/distance_weight", distance_weight, 0.6);
    nh.param("manager/target_weight", target_weight, 0.8);
    nh.param("manager/smoothness_weight", smoothness_weight, 0.1);
    nh.param("manager/feasibility_weight", feasibility_weight, 0.1);
    nh.param("manager/length_weight", length_weight, 0.2);
    nh.param("manager/speed_weight", speed_weight, 0.2);
    local_data_.traj_id_ = 0;
    grid_map_.reset(new GridMap);
    grid_map_->initMap(nh);
    bspline_optimizer_rebound_.reset(new BsplineOptimizer);
    bspline_optimizer_rebound_->setParam(nh);
    bspline_optimizer_rebound_->setEnvironment(grid_map_);
    bspline_optimizer_rebound_->a_star_.reset(new AStar);
    bspline_optimizer_rebound_->a_star_->initGridMap(grid_map_, Eigen::Vector3i(100, 100, 100));
    rrt_.reset(new RRT);
    rrt_->setParam(nh);
    rrt_->initGridMap(grid_map_, Eigen::Vector3i(100, 100, 100), 0.2);
    visualization_ = vis;
    astar_.reset(new AStar);
    astar_->initGridMap(grid_map_, Eigen::Vector3i(100, 100, 100));
    planner_client_ = nh.serviceClient<recfm_planner::Planner>("/planner_service");
}

bool ReCFMPlannerManager::reboundReplan(Eigen::Vector3d start_pt, Eigen::Vector3d start_vel, Eigen::Vector3d start_acc, Eigen::Vector3d local_target_pt, Eigen::Vector3d local_target_vel, Eigen::Vector3d local_target_acc, Eigen::Vector3d global_target_pt, bool flag_polyInit, bool flag_randomPolyTraj)
{
    static int count = 0;
    std::cout << endl << "\033[32m" << "[启动重新轨迹规划]: -------------------------------------" << count++ << "\033[0m" << std::endl;
    cout.precision(3);
    cout << "起始点: " << start_pt.transpose() << ", " << start_vel.transpose() << endl;
    cout << "目标点:" << local_target_pt.transpose() << ", " << local_target_vel.transpose() << endl;
    if ((start_pt - local_target_pt).norm() < 0.5){cout << "接近目标点" << endl;return false;}
    ros::Duration t_init, t_opt, t_refine, t_degraded, t_model, t_select;
    vector<Eigen::Vector3d> local_start_end, local_start_end_derivative;
    vector<Eigen::Vector3d> point_set, start_end, start_end_derivative;
    double ts;
    vector<vector<Eigen::Vector3d>> point_sets, start_ends, start_end_derivatives;
    vector<double> ts_sets;
    Eigen::MatrixXd ctrl_pts;
    vector<Eigen::MatrixXd> ctrl_pts_sets;
    vector<vector<Eigen::Vector3d>> init_point_sets, init_start_ends, init_start_end_derivatives;
    vector<double> init_ts_sets, optimal_ts_sets;
    vector<UniformBspline> pos_sets;
    local_target_acc = Eigen::Vector3d::Zero();
    local_start_end.clear(); local_start_end_derivative.clear();
    local_start_end.push_back(start_pt);
    local_start_end.push_back(local_target_pt);
    local_start_end_derivative.push_back(start_vel);
    local_start_end_derivative.push_back(local_target_vel);
    local_start_end_derivative.push_back(start_acc);
    local_start_end_derivative.push_back(local_target_acc);
    ros::Time t_start = ros::Time::now();
    std::vector<int> idx_seq;
    idx_seq.clear();
    const int K = 8;
    int trajectory_count = std::max(0, trajectory_num_ - 1);
    idx_seq.reserve(trajectory_count);
    int full_cycles = trajectory_count / K;
    int remainder = trajectory_count % K;
    for (int c = 0; c < full_cycles; ++c) {for (int j = 0; j < K; ++j) {idx_seq.push_back(j);}}
    if (remainder > 0) {std::array<int, K> base{0,1,2,3,4,5,6,7};std::mt19937 rng(std::random_device{}()); std::shuffle(base.begin(), base.end(), rng);
        for (int r = 0; r < remainder; ++r) {idx_seq.push_back(base[r]);}}
    static const std::array<Eigen::Vector2d, 8> SQ = {Eigen::Vector2d(+1.0, +1.0),Eigen::Vector2d(+1.0, -1.0),Eigen::Vector2d(-1.0, +1.0),Eigen::Vector2d(-1.0, -1.0),
                                                    Eigen::Vector2d(+1.0,  0.0),Eigen::Vector2d(-1.0,  0.0),Eigen::Vector2d( 0.0, +1.0),Eigen::Vector2d( 0.0, -1.0)};
    point_sets.clear(); ts_sets.clear(); start_end_derivatives.clear();
    Eigen::Vector3d horizen_dir = ((start_pt - local_target_pt).cross(Eigen::Vector3d(0, 0, 1))).normalized();
    Eigen::Vector3d vertical_dir = ((start_pt - local_target_pt).cross(horizen_dir)).normalized();
    double alpha = 3.0/4.0;
    Eigen::Vector3d mid = (1.0 - alpha) * start_pt + alpha * local_target_pt;
    for (int i = 0; i < trajectory_num_; ++i)
    {
        if (i == 0)
        {
            double dist = (start_pt - local_target_pt).norm();
            double time = pow(pp_.max_vel_, 2) / pp_.max_acc_ > dist ? sqrt(2*dist / pp_.max_acc_) : (dist - pow(pp_.max_vel_, 2) / pp_.max_acc_) / pp_.max_vel_ + 2 * pp_.max_vel_ / pp_.max_acc_;
            double t;
            double ts= time/17;
            point_set.clear(); start_end.clear(); start_end_derivative.clear();
            PolynomialTraj gl_traj = PolynomialTraj::one_segment_traj_gen(start_pt, start_vel, start_acc, local_target_pt, local_target_vel, local_target_acc, time);
            Eigen::Vector3d last_pt = gl_traj.evaluate(0);
            for (t = 0; t <= time+0.5*ts; t += ts)
            {
                Eigen::Vector3d pt = gl_traj.evaluate(t);
                last_pt = pt;
                point_set.push_back(pt);
            }
            t -= ts;
            start_end.push_back(gl_traj.evaluate(0));
            start_end.push_back(gl_traj.evaluate(t));
            start_end_derivative.push_back(gl_traj.evaluateVel(0));
            start_end_derivative.push_back(gl_traj.evaluateVel(t));
            start_end_derivative.push_back(gl_traj.evaluateAcc(0));
            start_end_derivative.push_back(gl_traj.evaluateAcc(t));
            ts_sets.push_back(ts);
            point_sets.push_back(point_set);
            start_end_derivatives.push_back(start_end_derivative);
            start_ends.push_back(start_end);
        }
        else
        {
            const int K = 8; int j = i - 1;int ring_index = j / K;int sel = idx_seq[j];
            double half_ring = 0.04 * (start_pt - local_target_pt).norm() + 0.05 * ring_index * (start_pt - local_target_pt).norm();
            Eigen::Vector2d offs2 = SQ[sel] * half_ring; Eigen::Vector3d inserted_pt = mid + offs2.x() * horizen_dir + offs2.y() * vertical_dir;
            double dist = (start_pt - inserted_pt).norm() + (local_target_pt - inserted_pt).norm();
            Eigen::MatrixXd pos(3, 3);pos.col(0) = start_pt;pos.col(1) = inserted_pt;pos.col(2) = local_target_pt;
            double time = pow(pp_.max_vel_, 2) / pp_.max_acc_ > dist ? sqrt(2*dist / pp_.max_acc_) : (dist - pow(pp_.max_vel_, 2) / pp_.max_acc_) / pp_.max_vel_ + 2 * pp_.max_vel_ / pp_.max_acc_;
            double t;
            double ts= time/17;
            point_set.clear(); start_end.clear(); start_end_derivative.clear();
            Eigen::VectorXd t_snap(2);t_snap(0)=time * alpha; t_snap(1)=time *(1-alpha);
            PolynomialTraj gl_traj = PolynomialTraj::minSnapTraj(pos, start_vel, local_target_vel, start_acc, local_target_acc, t_snap);
            Eigen::Vector3d last_pt = gl_traj.evaluate(0);
            for (t = 0; t <= time+0.5*ts; t += ts)
            {
                Eigen::Vector3d pt = gl_traj.evaluate(t);
                last_pt = pt;
                point_set.push_back(pt);
            }
            t -= ts;
            start_end.push_back(gl_traj.evaluate(0));
            start_end.push_back(gl_traj.evaluate(t));
            start_end_derivative.push_back(gl_traj.evaluateVel(0));
            start_end_derivative.push_back(gl_traj.evaluateVel(t));
            start_end_derivative.push_back(gl_traj.evaluateAcc(0));
            start_end_derivative.push_back(gl_traj.evaluateAcc(t));
            ts_sets.push_back(ts);
            point_sets.push_back(point_set);
            start_end_derivatives.push_back(start_end_derivative);
            start_ends.push_back(start_end);
        }
    }
    t_degraded = ros::Time::now() - t_start;
    visualization_->displayDegradedPathList(point_sets, 0.1, 0);
    ros::service::waitForService("/planner_service");
    pcl::PointCloud<pcl::PointXYZ> depth_cloud_ = grid_map_->getDepthCloud();
    if (depth_cloud_.empty()){ std::cout << "等待接收环境点云数据......" << std::endl; return false;}
    pcl::toROSMsg(depth_cloud_, planner_srv_.request.depth_cloud);
    planner_srv_.request.unadjusted_trajectories.clear();
    planner_srv_.request.unadjusted_trajectories.reserve(start_ends.size());
    for (size_t i = 0; i < start_ends.size(); ++i)
    {
        recfm_planner::Trajectory trajectory_;
        for (const auto& point : local_start_end)
        {
            geometry_msgs::Point point_msg; point_msg.x = point[0]; point_msg.y = point[1]; point_msg.z = point[2];
            trajectory_.start_end_condition.push_back(point_msg);
        }
        for (const auto& point : local_start_end_derivative)
        {
            geometry_msgs::Point point_msg; point_msg.x = point[0]; point_msg.y = point[1]; point_msg.z = point[2];
            trajectory_.start_end_condition.push_back(point_msg);
        }
        point_set = point_sets[i];
        for (const auto& point : point_set)
        {
            geometry_msgs::Point point_msg; point_msg.x = point[0]; point_msg.y = point[1]; point_msg.z = point[2];
            trajectory_.point_set.push_back(point_msg);
        }
        trajectory_.ts = ts_sets[i];
        planner_srv_.request.unadjusted_trajectories.push_back(trajectory_);
    }
    if (!planner_client_.call(planner_srv_)) {ROS_ERROR("请求服务端响应失败...."); return false;}
    point_sets.clear(); point_sets.reserve(planner_srv_.response.adjusted_trajectories.size());
    ts_sets.clear(); ts_sets.reserve(planner_srv_.response.adjusted_trajectories.size());
    for (const auto& trajectory : planner_srv_.response.adjusted_trajectories)
    {
        point_set.clear(); point_set.reserve(trajectory.point_set.size());
        for (const auto& pt : trajectory.point_set)
        {
            point_set.emplace_back(pt.x, pt.y, pt.z);
        }
        ts = trajectory.ts;
        point_sets.push_back(point_set);
        ts_sets.push_back(ts);
    }
    visualization_->displayInitPathList(point_sets, 0.1, 0);
    t_model = ros::Duration(planner_srv_.response.calculation_time);
    t_init = t_degraded + t_model;
    t_start = ros::Time::now();
    ctrl_pts_sets.clear();
    for (size_t i = 0; i < point_sets.size(); ++i)
    {
        point_set = point_sets[i];
        ts = ts_sets[i];
        start_end_derivative = start_end_derivatives[i];
        Eigen::MatrixXd ctrl_pts;
        UniformBspline::parameterizeToBspline(ts, point_set, start_end_derivative, ctrl_pts);
        ctrl_pts_sets.push_back(ctrl_pts);
    }
    vector<double> score_sets = bspline_optimizer_rebound_->calcTrajectoryScore(ctrl_pts_sets, ts_sets, global_target_pt, target_weight, length_weight, distance_weight, smoothness_weight, feasibility_weight, speed_weight);
    double max_score = *std::max_element(score_sets.begin(), score_sets.end());
    std::vector<int> max_score_indices; for (size_t i = 0; i < score_sets.size(); ++i) {if (score_sets[i] == max_score) {max_score_indices.push_back(i);}}
    std::random_device rd; std::mt19937 gen(rd()); std::uniform_int_distribution<> dis(0, max_score_indices.size() - 1); int optimal_index = max_score_indices[dis(gen)];
    ctrl_pts = ctrl_pts_sets[optimal_index];ts = ts_sets[optimal_index];point_set = point_sets[optimal_index];start_end_derivative = start_end_derivatives[optimal_index];
    cout << "从待选轨迹中选择的轨迹为：" << optimal_index << endl;
    t_select = ros::Time::now() - t_start;
    if(!planning_optimiaztion_)
    {
        t_opt = ros::Duration(0); t_refine = ros::Duration(0);
        UniformBspline pos = UniformBspline(ctrl_pts, 3, ts);
        updateTrajInfo(pos, ros::Time::now());
        cout << "\033[32m" << "重新规划总耗时(s):" << (t_init + t_opt + t_refine).toSec() << ",退化轨迹耗时(s):" << t_degraded.toSec() << ",模型推理耗时(s):" << t_model.toSec() << ",轨迹优化耗时(s):" << t_opt.toSec() << ",轨迹细化耗时(s):" << t_refine.toSec() << "\033[0m" << endl;
    }
    else
    {
        t_start = ros::Time::now();
        bspline_optimizer_rebound_->initControlPoints(ctrl_pts, true);
        bool flag_step_1_success = bspline_optimizer_rebound_->BsplineOptimizeTrajRebound(ctrl_pts, ts);
        cout << "first_optimize_step_success=" << flag_step_1_success << endl;
        if (!flag_step_1_success){return false;}
        t_opt = ros::Time::now() - t_start;
        t_start = ros::Time::now();
        UniformBspline pos = UniformBspline(ctrl_pts, 3, ts);
        pos.setPhysicalLimits(pp_.max_vel_, pp_.max_acc_, pp_.feasibility_tolerance_);
        double ratio = pos.calcFeasibilityRatio();
        double t_inc;
        reparamBspline(pos, start_end_derivative, ratio, ctrl_pts, ts, t_inc);
        bspline_optimizer_rebound_->initControlPoints(ctrl_pts, true);
        bool flag_step_2_success = bspline_optimizer_rebound_->BsplineOptimizeTrajRebound(ctrl_pts, ts);
        cout << "second_optimize_step_success=" << flag_step_2_success << endl;
        if (flag_step_2_success){pos = UniformBspline(ctrl_pts, 3, ts);}
        if (!flag_step_2_success){continous_failures_count_++; return false;}
        t_refine = ros::Time::now() - t_start;
        updateTrajInfo(pos, ros::Time::now());
        cout << "\033[32m" << "重新规划总耗时(s):" << (t_init + t_opt + t_refine).toSec() << ",退化轨迹耗时(s):" << t_degraded.toSec() << ",模型推理耗时(s):" << t_model.toSec() << ",轨迹优化耗时(s):" << t_opt.toSec() << ",轨迹细化耗时(s):" << t_refine.toSec() << "\033[0m" << endl;
    }
    return true;
}

bool ReCFMPlannerManager::EmergencyStop(Eigen::Vector3d stop_pos)
{
    Eigen::MatrixXd control_points(3, 6);
    for (int i = 0; i < 6; i++)
    {
        control_points.col(i) = stop_pos;
    }
    updateTrajInfo(UniformBspline(control_points, 3, 1.0), ros::Time::now());
    return true;
}

bool ReCFMPlannerManager::planGlobalTraj(const Eigen::Vector3d &start_pos, const Eigen::Vector3d &start_vel, const Eigen::Vector3d &start_acc, const Eigen::Vector3d &end_pos, const Eigen::Vector3d &end_vel, const Eigen::Vector3d &end_acc)
{
    vector<Eigen::Vector3d> points;
    points.push_back(start_pos);
    points.push_back(end_pos);
    vector<Eigen::Vector3d> inter_points;
    const double dist_thresh = 4.0;
    for (size_t i = 0; i < points.size() - 1; ++i)
    {
        inter_points.push_back(points.at(i));
        double dist = (points.at(i + 1) - points.at(i)).norm();
        if (dist > dist_thresh)
        {
            int id_num = floor(dist / dist_thresh) + 1;
            for (int j = 1; j < id_num; ++j)
            {
                Eigen::Vector3d inter_pt = points.at(i) * (1.0 - double(j) / id_num) + points.at(i + 1) * double(j) / id_num;
                inter_points.push_back(inter_pt);
            }
        }
    }
    inter_points.push_back(points.back());
    int pt_num = inter_points.size();
    Eigen::MatrixXd pos(3, pt_num);
    for (int i = 0; i < pt_num; ++i)
        pos.col(i) = inter_points[i];
    Eigen::VectorXd time(pt_num - 1);
    for (int i = 0; i < pt_num - 1; ++i)
    {
        time(i) = (pos.col(i + 1) - pos.col(i)).norm() / (pp_.max_vel_);
    }
    time(0) *= 2.0;
    time(time.rows() - 1) *= 2.0;
    PolynomialTraj gl_traj;
    if (pos.cols() >= 3)
        gl_traj = PolynomialTraj::minSnapTraj(pos, start_vel, end_vel, start_acc, end_acc, time);
    else if (pos.cols() == 2)
        gl_traj = PolynomialTraj::one_segment_traj_gen(start_pos, start_vel, start_acc, end_pos, end_vel, end_acc, time(0));
    else
        return false;
    auto time_now = ros::Time::now();
    global_data_.setGlobalTraj(gl_traj, time_now);
    return true;
}

bool ReCFMPlannerManager::planGlobalTrajWaypoints(const Eigen::Vector3d &start_pos, const Eigen::Vector3d &start_vel, const Eigen::Vector3d &start_acc, const std::vector<Eigen::Vector3d> &waypoints, const Eigen::Vector3d &end_vel, const Eigen::Vector3d &end_acc)
{
    vector<Eigen::Vector3d> points;
    points.push_back(start_pos);
    for (size_t wp_i = 0; wp_i < waypoints.size(); wp_i++)
    {
        points.push_back(waypoints[wp_i]);
    }
    double total_len = 0;
    total_len += (start_pos - waypoints[0]).norm();
    for (size_t i = 0; i < waypoints.size() - 1; i++)
    {
        total_len += (waypoints[i + 1] - waypoints[i]).norm();
    }
    vector<Eigen::Vector3d> inter_points;
    double dist_thresh = max(total_len / 8, 4.0);
    for (size_t i = 0; i < points.size() - 1; ++i)
    {
        inter_points.push_back(points.at(i));
        double dist = (points.at(i + 1) - points.at(i)).norm();
        if (dist > dist_thresh)
        {
            int id_num = floor(dist / dist_thresh) + 1;
            for (int j = 1; j < id_num; ++j)
            {
                Eigen::Vector3d inter_pt = points.at(i) * (1.0 - double(j) / id_num) + points.at(i + 1) * double(j) / id_num;
                inter_points.push_back(inter_pt);
            }
        }
    }
    inter_points.push_back(points.back());
    int pt_num = inter_points.size();
    Eigen::MatrixXd pos(3, pt_num);
    for (int i = 0; i < pt_num; ++i)
        pos.col(i) = inter_points[i];
    Eigen::VectorXd time(pt_num - 1);
    for (int i = 0; i < pt_num - 1; ++i)
    {
        time(i) = (pos.col(i + 1) - pos.col(i)).norm() / (pp_.max_vel_);
    }
    time(0) *= 2.0;
    time(time.rows() - 1) *= 2.0;
    PolynomialTraj gl_traj;
    if (pos.cols() >= 3)
        gl_traj = PolynomialTraj::minSnapTraj(pos, start_vel, end_vel, start_acc, end_acc, time);
    else if (pos.cols() == 2)
        gl_traj = PolynomialTraj::one_segment_traj_gen(start_pos, start_vel, start_acc, pos.col(1), end_vel, end_acc, time(0));
    else
        return false;
    auto time_now = ros::Time::now();
    global_data_.setGlobalTraj(gl_traj, time_now);
    return true;
}

void ReCFMPlannerManager::saveOptimalPathToCSV(UniformBspline &optimal_path, const double &ts, const vector<Eigen::Vector3d> &start_end, const std::string &folder_path)
{
    std::vector<Eigen::Vector3d> optimal_point_set;
    for (double t = 0; t < optimal_path.getTimeSum() + 1e-3; t += ts)
    {
        optimal_point_set.push_back(optimal_path.evaluateDeBoorT(t));
    }
    if (!optimal_point_set.empty()) {
        optimal_point_set.front() = start_end[0];
        optimal_point_set.back()  = start_end[1];
    }
    std::string optimal_path_csv_file_path = folder_path  + "/optimal_path.csv";
    std::ofstream optimal_path_csv_file(optimal_path_csv_file_path);
    optimal_path_csv_file.is_open();
    for (const auto& point : optimal_point_set)
    {
        optimal_path_csv_file << point.x()-start_end[0].x() << "," << point.y()-start_end[0].y() << "," << point.z()-start_end[0].z() << "," << ts <<"\n";
    }
    optimal_path_csv_file.close();
}

void ReCFMPlannerManager::saveInitPathToCSV(const vector<Eigen::Vector3d> &init_path, const double &ts, const vector<Eigen::Vector3d> &start_end, const std::string &folder_path)
{
    std::string init_path_csv_file_path = folder_path + "/init_path.csv";
    std::ofstream init_path_csv_file(init_path_csv_file_path);
    init_path_csv_file.is_open();
    for (const auto& point : init_path)
    {
        init_path_csv_file << point.x()-start_end[0].x() << "," << point.y()-start_end[0].y() << "," << point.z()-start_end[0].z() << "," << ts <<"\n";
    }
}

void ReCFMPlannerManager::saveStartEndToCSV(const vector<Eigen::Vector3d> &start_end, const vector<Eigen::Vector3d> &start_end_derivatives, const std::string &folder_path)
{
    std::string start_end_csv_file_path = folder_path + "/start_end.csv";
    std::ofstream start_end_csv_file(start_end_csv_file_path);
    start_end_csv_file.is_open();
    for (const auto& point : start_end)
    {
        start_end_csv_file << point.x()-start_end[0].x() << "," << point.y()-start_end[0].y() << "," << point.z()-start_end[0].z() <<"\n";
    }
    for (const auto& point : start_end_derivatives)
    {
        start_end_csv_file << point.x() << "," << point.y() << "," << point.z() <<"\n";
    }
    start_end_csv_file.close();
}

bool ReCFMPlannerManager::saveDeepCloudToCSV(const vector<Eigen::Vector3d> &start_end, const std::string &folder_path)
{
    std::string deep_cloud_csv_file_path = folder_path + "/deep_cloud.csv";
    pcl::PointCloud<pcl::PointXYZ> depth_cloud_ = grid_map_->getDepthCloud();
    if (depth_cloud_.empty()){return false;}
    std::ofstream deep_cloud_csv_file(deep_cloud_csv_file_path);
    deep_cloud_csv_file.is_open();
    for (size_t i = 0; i < depth_cloud_.points.size(); ++i)
    {
        pcl::PointXYZ point = depth_cloud_.points[i];
        deep_cloud_csv_file << point.x - start_end[0].x() << "," << point.y - start_end[0].y() << "," << point.z - start_end[0].z() << "\n";
    }
    deep_cloud_csv_file.close();
    return true;
}

std::string ReCFMPlannerManager::createTimeStampFolder(const std::string& save_path)
{
    if (!boost::filesystem::exists(save_path)) {boost::filesystem::create_directories(save_path);}
    std::time_t now = std::time(nullptr);
    std::tm* ltm = std::localtime(&now);
    int year = ltm->tm_year + 1900;
    int month = ltm->tm_mon + 1;
    int day = ltm->tm_mday;
    int hour = ltm->tm_hour;
    int minute = ltm->tm_min;
    int second = ltm->tm_sec;
    ros::Time current_time = ros::Time::now();
    std::stringstream folder_name;
    folder_name << save_path << "/"
                << year << "_"
                << std::setw(2) << std::setfill('0') << month << "_"
                << std::setw(2) << std::setfill('0') << day << "_"
                << std::setw(2) << std::setfill('0') << hour << "_"
                << std::setw(2) << std::setfill('0') << minute << "_"
                << std::setw(2) << std::setfill('0') << second<< "_"
                << std::setw(2) << std::setfill('0') << second<< "_"
                << std::setw(9) << std::setfill('0') << current_time.sec<< "_"
                << std::setw(9) << std::setfill('0') << current_time.nsec;
    std::string folder_path = folder_name.str();
    mkdir(folder_path.c_str(), 0777);
    return folder_path;
}

std::string ReCFMPlannerManager::getWorkspacePath()
{
    boost::filesystem::path exe_path(boost::filesystem::read_symlink("/proc/self/exe").parent_path());
    while (!exe_path.empty() && !(boost::filesystem::exists(exe_path / "src")))
        exe_path = exe_path.parent_path();
    if (exe_path.empty())
    {
        ROS_WARN("Cannot locate workspace root, fallback to /tmp");
        return "/tmp";
    }
    return exe_path.string();
}
}
