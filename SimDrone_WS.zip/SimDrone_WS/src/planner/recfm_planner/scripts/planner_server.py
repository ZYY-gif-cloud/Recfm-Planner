#! /home/sia-zyy/deep_learning_platform/platform/miniconda3/envs/mytorch/bin/python
import sys, os, uuid, time
sys.path.insert(0, os.path.dirname(__file__))
import rospy
import torch
import numpy as np
from geometry_msgs.msg import Point
from collections import defaultdict
from queue import Queue, Empty
from termcolor import cprint

from CFM_deploy import load_workspace
from recfm_planner.srv import Planner, PlannerResponse
from recfm_planner.msg import Trajectory

req_q = Queue(maxsize=1)
resp_db = defaultdict(lambda: None)
first_run = True

def handle_request(req):
    ticket = uuid.uuid4().hex
    try:
        req_q.put_nowait((ticket, req))
    except Exception:
        return _empty_response()
    timeout = time.time() + 5.0
    while time.time() < timeout and not rospy.is_shutdown():
        if resp_db.get(ticket):
            resp = resp_db.pop(ticket)
            return resp
        time.sleep(0.0001)
    resp_db.pop(ticket, None)
    return _empty_response()

def _empty_response():
    resp = PlannerResponse()
    resp.ts = 0.0
    resp.optimal_path_points = []
    return resp

def main_loop():
    while not rospy.is_shutdown():
        try:
            ticket, req = req_q.get(timeout=0.01)
        except Empty:
            continue
        start_condition = req.unadjusted_trajectories[0].start_end_condition[0]
        start_position = torch.tensor([start_condition.x, start_condition.y, start_condition.z], dtype=torch.float32)
        start_end_conditions = torch.tensor([[[p.x, p.y, p.z] for p in trajectory.start_end_condition] for trajectory in req.unadjusted_trajectories], dtype=torch.float32)
        start_end_conditions[:, :2] -= start_position
        init_paths = torch.tensor([[[p.x, p.y, p.z] for p in trajectory.point_set] for trajectory in req.unadjusted_trajectories], dtype=torch.float32) - start_position.unsqueeze(0).unsqueeze(0)
        ts_tensor = torch.tensor([trajectory.ts for trajectory in req.unadjusted_trajectories], dtype=torch.float32).unsqueeze(-1).unsqueeze(-1)
        init_paths = torch.cat((init_paths, ts_tensor.expand(-1, init_paths.shape[1], 1)), dim=2)
        deep_cloud = torch.from_numpy(np.frombuffer(req.depth_cloud.data, np.uint8).view(np.float32).reshape(-1, req.depth_cloud.point_step // 4)[:, :3].copy()).sub_(start_position)
        deep_clouds = deep_cloud.unsqueeze(0)
        model_input = {"deep_cloud":deep_clouds , "start_end":start_end_conditions , "init_traj":init_paths}
        global first_run
        if first_run:
            cprint("模型预热中..........................", "green")
            workspace.run(model_input)
            first_run = False
            cprint("模型预热完成..........................", "green")
        start_time = time.time()
        optimal_paths = workspace.run(model_input)
        optimal_paths = optimal_paths.cpu().numpy()
        end_time = time.time()
        calculation_time = end_time - start_time
        cprint("------------------------------------------------------------", "green")
        cprint(f"模型推理耗时: {calculation_time} s", "green")
        cprint("------------------------------------------------------------", "green")
        response = PlannerResponse()
        trajectories = []
        optimal_path_points = optimal_paths[:, :, 0:3] + start_position.cpu().numpy()
        for i in range(optimal_paths.shape[0]):
            trajectory = Trajectory()
            trajectory.ts = float(optimal_paths[i, :, -1].mean())
            trajectory.point_set = [Point(x=float(pt[0]), y=float(pt[1]), z=float(pt[2])) for pt in optimal_path_points[i]]
            trajectories.append(trajectory)
        response.adjusted_trajectories = trajectories
        response.calculation_time = calculation_time
        resp_db[ticket] = response

if __name__ == "__main__":
    rospy.init_node('planner_server')
    cprint("开始加载模型..........................", "green")
    workspace = load_workspace()
    cprint("完成模型加载..........................", "green")
    rospy.Service("/planner_service", Planner, handle_request)
    cprint("[轨迹规划服务]: 准备就绪", "green")
    main_loop()












