#ifndef RRT_H_
#define RRT_H_
#include <Eigen/Eigen>
#include <ros/ros.h>
#include <random>
#include <queue>
#include <recfm_plan_env/grid_map.h>
#include <recfm_path_searching/kdtree.h>

using namespace std;
using namespace Eigen;

#define inf (1 << 30);

class RRTPathNode
{
public:
  Eigen::Vector3d position;
  double g_cost;
  RRTPathNode* parent;
  std::vector<RRTPathNode*> children;
  RRTPathNode(){}
  ~RRTPathNode(){}
};
typedef RRTPathNode* RRTPathNodePtr;

class RRT
{
private:
  kdtree* kdtree_;
  std::vector<RRTPathNodePtr> path_node_pool_;
  int max_tree_node_num_;
  int use_node_num_;
  double step_length_;
  double max_allowed_time_;
  double tolerance_;
  double search_radius_;
  GridMap::Ptr grid_map_;
  Eigen::Vector3d origin_;
  Eigen::Vector3d map_size_;
  double resolution_;
  Eigen::Vector3i CENTER_IDX_, POOL_SIZE_;
  Eigen::Vector3d center_;
  double step_size_;
  double goalBiasProbability_;
  Eigen::Vector3d getRandomNode();
  inline Eigen::Vector3d Index2Coord(const Eigen::Vector3i &index) const;
  Eigen::Vector3d Step(Eigen::Vector3d from, Eigen::Vector3d to, double step_length);
  bool isCollisionFree(Eigen::Vector3d from, Eigen::Vector3d to, double map_resolution);
  void retrievePath(RRTPathNodePtr node, std::vector<Eigen::Vector3d>& path);
public:
  typedef std::shared_ptr<RRT> Ptr;
  RRT() {}
  ~RRT();
  void setParam(ros::NodeHandle& nh);
  void initGridMap(GridMap::Ptr occ_map, const Eigen::Vector3i pool_size, const double step_size );
  void getWholeTree(std::vector<Eigen::Vector3d>& vertices, std::vector<std::pair<Eigen::Vector3d, Eigen::Vector3d>>& edges);
  bool search(Eigen::Vector3d start_pt, Eigen::Vector3d end_pt, std::vector<Eigen::Vector3d>& path);
};

#endif
