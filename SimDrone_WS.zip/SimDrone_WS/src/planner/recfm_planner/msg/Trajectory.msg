geometry_msgs/Point[] point_set
geometry_msgs/Point[] start_end_condition
float64 ts