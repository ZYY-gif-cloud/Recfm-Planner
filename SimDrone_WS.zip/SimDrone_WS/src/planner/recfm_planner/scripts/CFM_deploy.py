#! /home/sia-zyy/deep_learning_platform/platform/miniconda3/envs/mytorch/bin/python
import os
from flow_matching_policy.workspace.base_workspace import BaseWorkspace
import pathlib
from omegaconf import OmegaConf
import hydra
from termcolor import cprint
import sys

sys.stdout = open(sys.stdout.fileno(), mode='w', buffering=1)
sys.stderr = open(sys.stderr.fileno(), mode='w', buffering=1)

os.environ['WANDB_SILENT'] = "True"
os.environ['NUMEXPR_MAX_THREADS'] = '16'

OmegaConf.register_new_resolver("eval", eval, replace=True)

def load_hydra_config(config_path: str, config_name: str) -> OmegaConf:
    hydra.initialize(version_base=None, config_path=config_path)
    cfg = hydra.compose(config_name=config_name)
    OmegaConf.resolve(cfg)
    return cfg

def load_workspace():
    config_path = "config"
    cfg = load_hydra_config(config_path=config_path, config_name="Deploy_CFM")
    cls = hydra.utils.get_class(cfg._target_)
    workspace: BaseWorkspace = cls(cfg)
    return workspace

def load_policy():
    config_path = "config"
    cfg = load_hydra_config(config_path=config_path, config_name="Deploy_CFM")
    cls = hydra.utils.get_class(cfg._target_)
    workspace: BaseWorkspace = cls(cfg)
    policy = workspace.policy
    return policy
