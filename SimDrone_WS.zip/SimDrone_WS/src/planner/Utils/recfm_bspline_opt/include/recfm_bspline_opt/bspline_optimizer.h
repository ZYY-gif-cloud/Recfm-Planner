#ifndef _BSPLINE_OPTIMIZER_H_
#define _BSPLINE_OPTIMIZER_H_
#include <Eigen/Eigen>
#include <recfm_path_searching/dyn_a_star.h>
#include <recfm_bspline_opt/uniform_bspline.h>
#include <recfm_plan_env/grid_map.h>
#include <ros/ros.h>
#include "recfm_bspline_opt/lbfgs.hpp"
namespace recfm_planner
{
  class ControlPoints
  {
  public:
    double clearance;
    int size;
    Eigen::MatrixXd points;
    std::vector<std::vector<Eigen::Vector3d>> base_point;
    std::vector<std::vector<Eigen::Vector3d>> direction;
    std::vector<bool> flag_temp;
    void resize(const int size_set)
    {
      size = size_set;
      base_point.clear();
      direction.clear();
      flag_temp.clear();
      points.resize(3, size_set);
      base_point.resize(size);
      direction.resize(size);
      flag_temp.resize(size);
    }
  };
  class BsplineOptimizer
  {
  private:
    GridMap::Ptr grid_map_;
    enum FORCE_STOP_OPTIMIZE_TYPE
    {
      DONT_STOP,
      STOP_FOR_REBOUND,
      STOP_FOR_ERROR
    } force_stop_type_;
    double bspline_interval_;
    Eigen::Vector3d end_pt_;
    vector<Eigen::Vector3d> guide_pts_;
    vector<Eigen::Vector3d> waypoints_;
    vector<int> waypt_idx_;
    int max_num_id_, max_time_id_;
    int cost_function_;
    double start_time_;
    int order_;
    double lambda1_;
    double lambda2_, new_lambda2_;
    double lambda3_;
    double lambda4_;
    double dist0_;
    double max_vel_, max_acc_;
    int variable_num_;
    int iter_num_;
    Eigen::VectorXd best_variable_;
    double min_cost_;
    ControlPoints cps_;
    static double costFunction(const std::vector<double> &x, std::vector<double> &grad, void *func_data);
    void combineCost(const std::vector<double> &x, std::vector<double> &grad, double &cost);
    void calcSmoothnessCost(const Eigen::MatrixXd &q, double &cost, Eigen::MatrixXd &gradient, bool flag_use_jerk = true);
    void calcFeasibilityCost(const Eigen::MatrixXd &q, double &cost, Eigen::MatrixXd &gradient);
    void calcDistanceCostRebound(const Eigen::MatrixXd &q, double &cost, Eigen::MatrixXd &gradient, int iter_num, double smoothness_cost);
    void calcFitnessCost(const Eigen::MatrixXd &q, double &cost, Eigen::MatrixXd &gradient);
    bool check_collision_and_rebound(void);
    static int earlyExit(void *func_data, const double *x, const double *g, const double fx, const double xnorm, const double gnorm, const double step, int n, int k, int ls);
    static double costFunctionOptimize(void *func_data, const double *x, double *grad, const int n);
    static double costFunctionRebound(void *func_data, const double *x, double *grad, const int n);
    static double costFunctionRefine(void *func_data, const double *x, double *grad, const int n);
    bool traj_optimize();
    bool rebound_optimize();
    bool refine_optimize();
    void combineCostOptimize(const double *x, double *grad, double &f_combine, const int n);
    void combineCostRebound(const double *x, double *grad, double &f_combine, const int n);
    void combineCostRefine(const double *x, double *grad, double &f_combine, const int n);
  public:
    typedef unique_ptr<BsplineOptimizer> Ptr;
    BsplineOptimizer() {}
    ~BsplineOptimizer() {}
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
    AStar::Ptr a_star_;
    std::vector<Eigen::Vector3d> ref_pts_;
    void setEnvironment(const GridMap::Ptr &env);
    void setParam(ros::NodeHandle &nh);
    Eigen::MatrixXd BsplineOptimizeTraj(const Eigen::MatrixXd &points, const double &ts, const int &cost_function, int max_num_id, int max_time_id);
    void setControlPoints(const Eigen::MatrixXd &points);
    void setBsplineInterval(const double &ts);
    void setCostFunction(const int &cost_function);
    void setTerminateCond(const int &max_num_id, const int &max_time_id);
    void setGuidePath(const vector<Eigen::Vector3d> &guide_pt);
    void setWaypoints(const vector<Eigen::Vector3d> &waypts, const vector<int> &waypt_idx);
    Eigen::MatrixXd getControlPoints();
    std::vector<std::vector<Eigen::Vector3d>> initControlPoints(const Eigen::MatrixXd &init_points, bool flag_first_init = true);
    bool BsplineOptimizeTrajRebound(Eigen::MatrixXd &optimal_points, double ts);
    bool BsplineOptimizeTrajRefine(const Eigen::MatrixXd &init_points, const double ts, Eigen::MatrixXd &optimal_points);
    bool BsplineOptimizeTraj(const Eigen::MatrixXd &init_points, const double ts, Eigen::MatrixXd &optimal_points);
    inline int getOrder(void) { return order_; }
    double calculateTrajectoryCost(const Eigen::MatrixXd &ctrl_pts, double &ts, Eigen::Vector3d &local_target_pt);
    vector<double> calcTargetScore(const vector<Eigen::MatrixXd> &ctrl_pts_sets, const Eigen::Vector3d &local_target_pt);
    vector<double> calcLengthScore(const vector<Eigen::MatrixXd> &ctrl_pts_sets);
    vector<double> calcDistanceScore(const vector<Eigen::MatrixXd> &ctrl_pts_sets);
    vector<double> calcSmoothnessScore(const vector<Eigen::MatrixXd> &ctrl_pts_sets,const vector<double> &ts_sets);
    vector<double> calcFeasibilityScore(const vector<Eigen::MatrixXd> &ctrl_pts_sets,const vector<double> &ts_sets);
    vector<double> calcSpeedScore(const vector<Eigen::MatrixXd> &ctrl_pts_sets, const vector<double> &ts_sets);
    vector<double> calcTrajectoryScore(const vector<Eigen::MatrixXd> &ctrl_pts_sets , const vector<double> &ts_sets, Eigen::Vector3d &target_pt,
                                      double target_weight, double length_weight,double distance_weight, double smoothness_weight,double feasibility_weight,double speed_weight);
    vector<double> ts_sets;
    Eigen::MatrixXd ctrl_pts;
    vector<Eigen::MatrixXd> ctrl_pts_sets;
  };
} 
#endif
