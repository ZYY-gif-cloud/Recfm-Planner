#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include <recfm_planner/recfm_replan_fsm.h>

using namespace recfm_planner;

int main(int argc, char **argv)
{
  setlocale(LC_ALL, "");
  ros::init(argc, argv, "recfm_planner_node");
  ros::NodeHandle nh("~");
  ReCFMReplanFSM rebo_replan;
  rebo_replan.init(nh);
  ros::Duration(1.0).sleep();
  ros::spin();
  return 0;
}

