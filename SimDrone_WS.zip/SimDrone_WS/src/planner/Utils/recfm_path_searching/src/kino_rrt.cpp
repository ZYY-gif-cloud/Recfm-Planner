#include <recfm_path_searching/kino_rrt.h>

KinoRRT::~KinoRRT()
{
    kd_free(kdtree_);
    for (int i = 0; i < max_tree_node_num_; i++)
    {
        delete path_node_pool_[i];
    }
}

Eigen::Vector3d KinoRRT::getRandomNode()
{
    std::random_device rd;
    std::mt19937_64 gen(rd());
    std::uniform_real_distribution<double> dis(0, 1);
    Eigen::Vector3i x_idx;
    x_idx(0) = std::floor(dis(gen) * POOL_SIZE_(0) + 0.5);
    x_idx(1) = std::floor(dis(gen) * POOL_SIZE_(1) + 0.5);
    x_idx(2) = std::floor(dis(gen) * POOL_SIZE_(2) + 0.5);
    Eigen::Vector3d x_rand;
    x_rand = Index2Coord(x_idx);
    return x_rand;
}

inline Eigen::Vector3d KinoRRT::Index2Coord(const Eigen::Vector3i &index) const
{
    return ((index - CENTER_IDX_).cast<double>() * step_size_) + center_;
};

void KinoRRT::StateTransit(Eigen::Matrix<double, 6, 1>& x0, Eigen::Matrix<double, 6, 1>& xt, Eigen::Vector3d ut, double t)
{
    Eigen::Matrix<double, 6, 6> e_At = Eigen::Matrix<double, 6, 6>::Identity();
    for (int i = 0; i < 3; i++)
    {
        e_At(i, 3 + i) = t;
    }
    Eigen::Matrix<double, 6, 3> Integral = Eigen::Matrix<double, 6, 3>::Zero();
    for (int i = 0; i < 6; i++)
    {
        if (i < 3)
            Integral(i, i) = 0.5 * t * t;
        else
            Integral(i, i - 3) = t;
    }
    xt = e_At * x0 + Integral * ut;
}

void KinoRRT::Step(Eigen::Vector3d from_pt, Eigen::Vector3d from_vel, Eigen::Vector3d &to_pt, Eigen::Vector3d &to_vel, Eigen::Vector3d &ut, double &sample_duration) 
{
    Eigen::Vector3d sample_pt = to_pt;
    Eigen::Matrix<double, 6, 1> x0;
    x0 << from_pt, from_vel;
    Eigen::Matrix<double, 6, 1> xt;
    double min_dis = inf;
    for (double ax = -max_acc_; ax <= max_acc_; ax += acc_res_ * max_acc_) {
        for (double ay = -max_acc_; ay <= max_acc_; ay += acc_res_ * max_acc_) {
            for (double az = -max_acc_; az <= max_acc_; az += acc_res_ * max_acc_) {
                for (double t = 0.0; t <= max_sample_duration_ ; t += delta_duration_){ 
                    StateTransit(x0, xt, Eigen::Vector3d(ax, ay, az),t);
                    Eigen::Vector3d tmp_pos = xt.head(3);
                    if (grid_map_-> isInMap(tmp_pos) == false   ||   grid_map_->getInflateOccupancy(tmp_pos) == true)
                    {
                        break;
                    }
                    if (xt.tail(3)(0) < -max_vel_ || xt.tail(3)(0) > max_vel_ || xt.tail(3)(1) < -max_vel_ ||
                        xt.tail(3)(1) > max_vel_ || xt.tail(3)(2) < -max_vel_ || xt.tail(3)(2) > max_vel_)
                    {
                            break;
                    }
                    if((sample_pt-tmp_pos).norm()< min_dis)
                    {    
                        min_dis = (to_pt-tmp_pos).norm();
                        to_pt  = xt.head(3);
                        to_vel = xt.tail(3);
                        sample_duration = t ;
                        ut = Eigen::Vector3d(ax, ay, az);
                    }
                }
            }
        }
    }
}

void KinoRRT::Step(Eigen::Vector3d from_pt, Eigen::Vector3d from_vel, Eigen::Vector3d to_pt, RRTPathNodePtr &nearest_node)
{
    Eigen::Vector3d sample_pt = to_pt;
    Eigen::Matrix<double, 6, 1> x0;
    x0 << from_pt, from_vel;
    Eigen::Matrix<double, 6, 1> xt;
    double min_dis = inf;
    for (double ax = -max_acc_; ax <= max_acc_; ax += acc_res_ * max_acc_) {
        for (double ay = -max_acc_; ay <= max_acc_; ay += acc_res_ * max_acc_) {
            for (double az = -max_acc_; az <= max_acc_; az += acc_res_ * max_acc_) {
                for (double t = 0.0; t <= max_sample_duration_ ; t += delta_duration_){ 
                    StateTransit(x0, xt, Eigen::Vector3d(ax, ay, az),t);
                    Eigen::Vector3d tmp_pos = xt.head(3);
                    if (grid_map_-> isInMap(tmp_pos) == false   ||   grid_map_->getInflateOccupancy(tmp_pos) == true)
                    {
                        break;
                    }
                    if (xt.tail(3)(0) < -max_vel_ || xt.tail(3)(0) > max_vel_ || xt.tail(3)(1) < -max_vel_ ||
                        xt.tail(3)(1) > max_vel_ || xt.tail(3)(2) < -max_vel_ || xt.tail(3)(2) > max_vel_)
                    {
                            break;
                    }
                    if((sample_pt-tmp_pos).norm()< min_dis)
                    {    
                        min_dis = (to_pt-tmp_pos).norm();
                        RRTPathNodePtr x_new_node = path_node_pool_[use_node_num_];
                        x_new_node->position = xt.head(3);
                        x_new_node->velocity = xt.tail(3);
                        x_new_node->acceleration = Eigen::Vector3d(ax, ay, az);
                        x_new_node->duration = t;
                        x_new_node->parent = nearest_node;
                        nearest_node->children.push_back(x_new_node);
                        kd_insert(kdtree_, xt.head(3).data(), x_new_node);
                        use_node_num_++;
                    }
                }
            }
        }
    }
}

std::vector<RRTPathNodePtr> KinoRRT::retrievePath(RRTPathNodePtr end_node)
{
    RRTPathNodePtr current_node = end_node;
    std::vector<RRTPathNodePtr> path_nodes;
    while (current_node->parent != NULL)
    {
        path_nodes.push_back(current_node);
        times_.push_back(current_node->duration); 
        current_node = current_node->parent;
    }
    path_nodes.push_back(current_node);
    std::reverse(path_nodes.begin(), path_nodes.end());
    std::reverse(times_.begin(), times_.end());
    return path_nodes;
}

void KinoRRT::setParam(ros::NodeHandle& nh)
{
    nh.param("kino_rrt/max_tree_node_num", max_tree_node_num_, 100000);
    nh.param("kino_rrt/max_allowed_time", max_allowed_time_, 5.0);
    nh.param("kino_rrt/goal_tolerance", goal_tolerance_, 2.0);
    nh.param("kino_rrt/goalBiasProbability", goalBiasProbability_, 0.6);
    nh.param("kino_rrt/max_velocity", max_vel_, 2.0);
    nh.param("kino_rrt/max_accelration", max_acc_, 3.0);
    nh.param("kino_rrt/max_sample_duration", max_sample_duration_, 4.0);
    nh.param("kino_rrt/delta_duration", delta_duration_, 0.1);
    nh.param("kino_rrt/acc_resolution", acc_res_, 0.1);
    nh.param("kino_rrt/vel_resolution", vel_res_, 0.1);
}

void KinoRRT::initGridMap(GridMap::Ptr occ_map, const Eigen::Vector3i pool_size, const double step_size)
{
    step_size_ = step_size;
    POOL_SIZE_ = pool_size;
    CENTER_IDX_ = pool_size / 2;
    grid_map_ = occ_map;
    kdtree_ = kd_create(3);
    use_node_num_ = 0;
    path_node_pool_.resize(max_tree_node_num_);
    for (int i = 0; i < max_tree_node_num_; i++)
    {
        path_node_pool_[i] = new RRTPathNode();
    }
}

bool KinoRRT::RRTsearch(Eigen::Vector3d start_pt, Eigen::Vector3d start_vel, Eigen::Vector3d start_acc, Eigen::Vector3d end_pt, Eigen::Vector3d end_vel)
{
    center_ = (start_pt + end_pt) / 2;
    use_node_num_ = 0;
    kd_clear(kdtree_);
    for (int i = 0; i < max_tree_node_num_; i++)
    {
        RRTPathNodePtr node = path_node_pool_[i];
        node->position = Eigen::Vector3d::Zero();
        node->velocity = Eigen::Vector3d::Zero();
        node->acceleration = Eigen::Vector3d::Zero();
        node->duration = inf;
        node->children.clear();
        node->parent = NULL;
    }
    RRTPathNodePtr start_node = path_node_pool_[use_node_num_];
    start_node->position = start_pt;
    start_node->velocity = start_vel;
    start_node->acceleration = start_acc;
    start_node->parent = NULL;
    use_node_num_++;
    kd_insert(kdtree_, start_node->position.data(), start_node);
    Eigen::Matrix<double, 6, 1> x0;
    x0 << start_pt, start_vel;
    Eigen::Matrix<double, 6, 1> xt;
    for (double t = 0.0; t <= max_sample_duration_ ; t += delta_duration_) 
    {
        StateTransit(x0, xt, start_acc,t);
        Eigen::Vector3d tmp_pos = xt.head(3);
        if (grid_map_-> isInMap(tmp_pos) == false   ||   grid_map_->getInflateOccupancy(tmp_pos) == true)
        {
            break;
        }
        if (xt.tail(3)(0) < -max_vel_ || xt.tail(3)(0) > max_vel_ || xt.tail(3)(1) < -max_vel_ ||
            xt.tail(3)(1) > max_vel_ || xt.tail(3)(2) < -max_vel_ || xt.tail(3)(2) > max_vel_)
        {
            break;
        }
        RRTPathNodePtr x_new_node = path_node_pool_[use_node_num_];
        x_new_node->position = xt.head(3);
        x_new_node->velocity = xt.tail(3);
        x_new_node->acceleration = start_acc;
        x_new_node->duration = t;
        x_new_node->parent = start_node;
        start_node->children.push_back(x_new_node);
        kd_insert(kdtree_, x_new_node->position.data(), x_new_node);
        use_node_num_++;
    }

    ros::Time start_time = ros::Time::now();
    for (int i = 0; i < max_tree_node_num_; i++)
    {
        ros::Time current_time = ros::Time::now();
        if ((current_time - start_time).toSec() > max_allowed_time_)
        {
            std::cout << "reach max allowed time" << std::endl;
            return false;
        }

        std::random_device rd;
        std::mt19937_64 gen(rd());
        std::uniform_real_distribution<double> dis(0, 1);

        Eigen::Vector3d x_rand_pt_;
        Eigen::Vector3d x_rand_vel_;
        Eigen::Vector3d x_rand_acc_;

        if (dis(gen) < goalBiasProbability_)
        {
            x_rand_pt_ = end_pt;
        }
        else 
        {
            x_rand_pt_ = getRandomNode();
        }

        kdres* nearest_tree_node = kd_nearest(kdtree_, x_rand_pt_.data());
        RRTPathNodePtr nearest_node = static_cast<RRTPathNode*>(kd_res_item_data(nearest_tree_node));
        kd_res_free(nearest_tree_node);
        Eigen::Vector3d x_near_pt_ = nearest_node->position;
        Eigen::Vector3d x_near_vel_ = nearest_node->velocity;
        double sample_time_;

        Step(x_near_pt_, x_near_vel_, x_rand_pt_, nearest_node);

        kdres* nearesttree_node = kd_nearest(kdtree_, end_pt.data());
        RRTPathNodePtr nearestnode = static_cast<RRTPathNode*>(kd_res_item_data(nearesttree_node));
        kd_res_free(nearesttree_node);
        Eigen::Vector3d near_pt_ = nearestnode->position;

        if ((x_near_pt_ - end_pt).norm() <= goal_tolerance_)
        {
            Eigen::Vector3d end_acc_;
            Step(nearestnode->position, nearestnode->velocity, end_pt, end_vel , end_acc_, sample_time_);
                
            RRTPathNodePtr end_node = path_node_pool_[use_node_num_];
            use_node_num_++;

            end_node->position = end_pt;
            end_node->velocity = end_vel;
            end_node->acceleration = end_acc_;
            end_node->duration = sample_time_;
            end_node->parent = nearestnode;

            nearestnode->children.push_back(end_node);
            path_pool_ = retrievePath(end_node);
            std::cout << "reach end point" << std::endl;
            ros::Time end_time = ros::Time::now();
            double total_time = (end_time - start_time).toSec();
            std::cout << "total time: " << total_time << std::endl;
            return true;
        }
    }
    std::cout << "tree is full, no path found" << std::endl;
    return false;
}

std::vector<std::vector<Eigen::Vector3d>> KinoRRT::sampleCombinePath()
{   
    std::vector<std::vector<Eigen::Vector3d>> combine_paths;
    for (size_t i = 0; i < path_pool_.size() - 1; i++)
    {
        std::vector<Eigen::Vector3d> delta_path;
        RRTPathNodePtr curr_node = path_pool_[i];
        RRTPathNodePtr next_node = path_pool_[i + 1];
        Eigen::Matrix<double, 6, 1> x0, xt;
        x0 << curr_node->position, curr_node->velocity;
        for (double t = 0; t <= next_node->duration ; t += delta_duration_)
        {
                StateTransit(x0, xt, next_node->acceleration, t);
                delta_path.push_back(xt.head(3));
        }
        combine_paths.push_back(delta_path);
    }
    return combine_paths;
}

std::vector<Eigen::Vector3d> KinoRRT::samplePath()
{
    std::vector<Eigen::Vector3d> path;
    for (size_t i = 0; i < path_pool_.size() - 1; i++)
    {
        std::vector<Eigen::Vector3d> delta_path;
        RRTPathNodePtr curr_node = path_pool_[i];
        RRTPathNodePtr next_node = path_pool_[i + 1];
        Eigen::Matrix<double, 6, 1> x0, xt;
        x0 << curr_node->position, curr_node->velocity;
        for (double t = 0; t <= next_node->duration ; t += delta_duration_)
        {
                StateTransit(x0, xt, next_node->acceleration, t);
                path.push_back(xt.head(3));
        }
    }
    return path;
}

void KinoRRT::getWholeTree(std::vector<Eigen::Vector3d>& vertices, std::vector<std::pair<Eigen::Vector3d, Eigen::Vector3d>>& edges)
{
    RRTPathNodePtr start_node = path_node_pool_[0];
    vertices.push_back(start_node->position);
    std::queue<RRTPathNodePtr> bfs_queue;
    bfs_queue.push(start_node);
    while (!bfs_queue.empty())
    {
        RRTPathNodePtr curr_node = bfs_queue.front();
        bfs_queue.pop();
        if (curr_node->children.empty())
            continue;
        for (RRTPathNodePtr child : curr_node->children)
        {
            assert(std::find(child->children.begin(), child->children.end(), curr_node) == child->children.end());
            vertices.push_back(child->position);
            edges.push_back(std::make_pair(curr_node->position, child->position));
            bfs_queue.push(child);
        }
    }
}

Eigen::Vector3d KinoRRT::evaluate(double t) 
{
    int idx = 0;
    while (times_[idx] + 1e-4 < t)
    {
        t -= times_[idx];
        ++idx;
      }
    RRTPathNodePtr curr_node = path_pool_[idx];
    RRTPathNodePtr next_node = path_pool_[idx + 1];
    Eigen::Matrix<double, 6, 1> x0, xt;
    x0 << curr_node->position, curr_node->velocity;
    StateTransit(x0, xt, next_node->acceleration, t);
    return xt.head(3);
}

Eigen::Vector3d KinoRRT::evaluateVel(double t) 
{
    int idx = 0;
    while (times_[idx] + 1e-4 < t)
    {
        t -= times_[idx];
        ++idx;
    }
    RRTPathNodePtr curr_node = path_pool_[idx];
    RRTPathNodePtr next_node = path_pool_[idx + 1];
    Eigen::Matrix<double, 6, 1> x0, xt;
    x0 << curr_node->position, curr_node->velocity;
    StateTransit(x0, xt, next_node->acceleration, t);
    return xt.tail(3);
}

Eigen::Vector3d KinoRRT::evaluateAcc(double t) 
{
      int idx = 0;
      while (times_[idx] + 1e-4 < t)
      {
          t -= times_[idx];
          ++idx;
      }
      RRTPathNodePtr next_node = path_pool_[idx + 1];
      return next_node->acceleration;
}
