#include "recfm_bspline_opt/bspline_optimizer.h"
namespace recfm_planner
{
void BsplineOptimizer::calcSmoothnessCost(const Eigen::MatrixXd &q, double &cost, Eigen::MatrixXd &gradient, bool flag_use_jerk)
{
    cost = 0.0;
    if (flag_use_jerk)
    {
        Eigen::Vector3d jerk, temp_j;
        for (int i = 0; i < q.cols() - 3; i++)
        {
            jerk = q.col(i + 3) - 3 * q.col(i + 2) + 3 * q.col(i + 1) - q.col(i);
            cost += jerk.squaredNorm();
            temp_j = 2.0 * jerk;
            gradient.col(i + 0) += -temp_j;
            gradient.col(i + 1) += 3.0 * temp_j;
            gradient.col(i + 2) += -3.0 * temp_j;
            gradient.col(i + 3) += temp_j;
        }
    }
    else
    {
        Eigen::Vector3d acc, temp_acc;
        for (int i = 0; i < q.cols() - 2; i++)
        {
            acc = q.col(i + 2) - 2 * q.col(i + 1) + q.col(i);
            cost += acc.squaredNorm();
            temp_acc = 2.0 * acc;
            gradient.col(i + 0) += temp_acc;
            gradient.col(i + 1) += -2.0 * temp_acc;
            gradient.col(i + 2) += temp_acc;
        }
    }
}

void BsplineOptimizer::calcFeasibilityCost(const Eigen::MatrixXd &q, double &cost, Eigen::MatrixXd &gradient)
{
    cost = 0.0;
    double ts, ts_inv2;
    ts = bspline_interval_;
    ts_inv2 = 1 / ts / ts;
    for (int i = 0; i < q.cols() - 1; i++)
    {
        Eigen::Vector3d vi = (q.col(i + 1) - q.col(i)) / ts;
        for (int j = 0; j < 3; j++)
        {
            if (vi(j) > max_vel_)
            {
                cost += pow(vi(j) - max_vel_, 2) / pow(max_vel_, 2);
                gradient(j, i + 0) += -2 * (vi(j) - max_vel_) / ts / pow(max_vel_, 2);
                gradient(j, i + 1) += 2 * (vi(j) - max_vel_) / ts / pow(max_vel_, 2);
            }
            else if (vi(j) < -max_vel_)
            {
                cost += pow(vi(j) + max_vel_, 2) / pow(max_vel_, 2);
                gradient(j, i + 0) += -2 * (vi(j) + max_vel_) / ts / pow(max_vel_, 2);
                gradient(j, i + 1) += 2 * (vi(j) + max_vel_) / ts / pow(max_vel_, 2);
            }
        }
    }
    for (int i = 0; i < q.cols() - 2; i++)
    {
        Eigen::Vector3d ai = (q.col(i + 2) - 2 * q.col(i + 1) + q.col(i)) * ts_inv2;
        for (int j = 0; j < 3; j++)
        {
            if (ai(j) > max_acc_)
            {
                cost += pow(ai(j) - max_acc_, 2) / pow(max_acc_, 2);
                gradient(j, i + 0) += 2 * (ai(j) - max_acc_) * ts_inv2 / pow(max_acc_, 2);
                gradient(j, i + 1) += -4 * (ai(j) - max_acc_) * ts_inv2 / pow(max_acc_, 2);
                gradient(j, i + 2) += 2 * (ai(j) - max_acc_) * ts_inv2 / pow(max_acc_, 2);
            }
            else if (ai(j) < -max_acc_)
            {
                cost += pow(ai(j) + max_acc_, 2) / pow(max_acc_, 2);
                gradient(j, i + 0) += 2 * (ai(j) + max_acc_) * ts_inv2 / pow(max_acc_, 2);
                gradient(j, i + 1) += -4 * (ai(j) + max_acc_) * ts_inv2 / pow(max_acc_, 2);
                gradient(j, i + 2) += 2 * (ai(j) + max_acc_) * ts_inv2 / pow(max_acc_, 2);
            }
        }
    }
}

void BsplineOptimizer::calcDistanceCostRebound(const Eigen::MatrixXd &q, double &cost, Eigen::MatrixXd &gradient, int iter_num, double smoothness_cost)
{
    cost = 0.0;
    int end_idx = q.cols() - order_;
    double demarcation = cps_.clearance;
    double a = 3 * demarcation, b = -3 * pow(demarcation, 2), c = pow(demarcation, 3);
    force_stop_type_ = DONT_STOP;
    if (iter_num > 3 && smoothness_cost / (cps_.size - 2 * order_) < 0.1)
    {
        check_collision_and_rebound();
    }
    for (auto i = order_; i < end_idx; ++i)
    {
        for (size_t j = 0; j < cps_.direction[i].size(); ++j)
        {
            double dist = (cps_.points.col(i) - cps_.base_point[i][j]).dot(cps_.direction[i][j]);
            double dist_err = cps_.clearance - dist;
            Eigen::Vector3d dist_grad = cps_.direction[i][j];
            if (dist_err < 0)
            {
            }
            else if (dist_err < demarcation)
            {
                cost += pow(dist_err, 3);
                gradient.col(i) += -3.0 * dist_err * dist_err * dist_grad;
            }
            else
            {
                cost += a * dist_err * dist_err + b * dist_err + c;
                gradient.col(i) += -(2.0 * a * dist_err + b) * dist_grad;
            }
        }
    }
}

void BsplineOptimizer::calcFitnessCost(const Eigen::MatrixXd &q, double &cost, Eigen::MatrixXd &gradient)
{
    cost = 0.0;
    int end_idx = q.cols() - order_;
    double a2 = 25, b2 = 1;
    for (auto i = order_ - 1; i < end_idx + 1; ++i)
    {
        Eigen::Vector3d x = (q.col(i - 1) + 4 * q.col(i) + q.col(i + 1)) / 6.0 - ref_pts_[i - 1];
        Eigen::Vector3d v = (ref_pts_[i] - ref_pts_[i - 2]).normalized();
        double xdotv = x.dot(v);
        Eigen::Vector3d xcrossv = x.cross(v);
        double f = pow((xdotv), 2) / a2 + pow(xcrossv.norm(), 2) / b2;
        cost += f;
        Eigen::Matrix3d m;
        m << 0, -v(2), v(1), v(2), 0, -v(0), -v(1), v(0), 0;
        Eigen::Vector3d df_dx = 2 * xdotv / a2 * v + 2 / b2 * m * xcrossv;
        gradient.col(i - 1) += df_dx / 6;
        gradient.col(i) += 4 * df_dx / 6;
        gradient.col(i + 1) += df_dx / 6;
    }
}

bool BsplineOptimizer::check_collision_and_rebound(void)
{
    int end_idx = cps_.size - order_;
    int in_id, out_id;
    vector<std::pair<int, int>> segment_ids;
    bool flag_new_obs_valid = false;
    int i_end = end_idx - (end_idx - order_) / 3;
    for (int i = order_ - 1; i <= i_end; ++i)
    {
        bool occ = grid_map_->getInflateOccupancy(cps_.points.col(i));
        if (occ)
        {
            for (size_t k = 0; k < cps_.direction[i].size(); ++k)
            {
                cout.precision(2);
                if ((cps_.points.col(i) - cps_.base_point[i][k]).dot(cps_.direction[i][k]) < 1 * grid_map_->getResolution())
                {
                    occ = false;
                    break;
                }
            }
        }
        if (occ)
        {
            flag_new_obs_valid = true;
            int j;
            for (j = i - 1; j >= 0; --j)
            {
                occ = grid_map_->getInflateOccupancy(cps_.points.col(j));
                if (!occ)
                {
                    in_id = j;
                    break;
                }
            }
            if (j < 0)
            {
                ROS_ERROR("ERROR! the drone is in obstacle. This should not happen.");
                in_id = 0;
            }
            for (j = i + 1; j < cps_.size; ++j)
            {
                occ = grid_map_->getInflateOccupancy(cps_.points.col(j));
                if (!occ)
                {
                    out_id = j;
                    break;
                }
            }
            if (j >= cps_.size)
            {
                ROS_WARN("WARN! terminal point of the current trajectory is in obstacle, skip this planning.");
                force_stop_type_ = STOP_FOR_ERROR;
                return false;
            }
            i = j + 1;
            segment_ids.push_back(std::pair<int, int>(in_id, out_id));
        }
    }
    if (flag_new_obs_valid)
    {
        vector<vector<Eigen::Vector3d>> a_star_pathes;
        for (size_t i = 0; i < segment_ids.size(); ++i)
        {
            Eigen::Vector3d in(cps_.points.col(segment_ids[i].first)), out(cps_.points.col(segment_ids[i].second));
            if (a_star_->AstarSearch(0.1, in, out))
            {
                a_star_pathes.push_back(a_star_->getPath());
            }
            else
            {
                ROS_ERROR("a star error");
                segment_ids.erase(segment_ids.begin() + i);
                i--;
            }
        }
        for (size_t i = 0; i < segment_ids.size(); ++i)
        {
            for (int j = segment_ids[i].first; j <= segment_ids[i].second; ++j)
                cps_.flag_temp[j] = false;
            int got_intersection_id = -1;
            for (int j = segment_ids[i].first + 1; j < segment_ids[i].second; ++j)
            {
                Eigen::Vector3d ctrl_pts_law(cps_.points.col(j + 1) - cps_.points.col(j - 1)), intersection_point;
                int Astar_id = a_star_pathes[i].size() / 2, last_Astar_id;
                double val = (a_star_pathes[i][Astar_id] - cps_.points.col(j)).dot(ctrl_pts_law), last_val = val;
                while (Astar_id >= 0 && Astar_id < (int)a_star_pathes[i].size())
                {
                    last_Astar_id = Astar_id;
                    if (val >= 0)
                        --Astar_id;
                    else
                        ++Astar_id;
                    val = (a_star_pathes[i][Astar_id] - cps_.points.col(j)).dot(ctrl_pts_law);
                    if (val * last_val <= 0 && (abs(val) > 0 || abs(last_val) > 0))
                    {
                        intersection_point =
                            a_star_pathes[i][Astar_id] +
                            ((a_star_pathes[i][Astar_id] - a_star_pathes[i][last_Astar_id]) *
                             (ctrl_pts_law.dot(cps_.points.col(j) - a_star_pathes[i][Astar_id]) / ctrl_pts_law.dot(a_star_pathes[i][Astar_id] - a_star_pathes[i][last_Astar_id])));
                        got_intersection_id = j;
                        break;
                    }
                }
                if (got_intersection_id >= 0)
                {
                    cps_.flag_temp[j] = true;
                    double length = (intersection_point - cps_.points.col(j)).norm();
                    if (length > 1e-5)
                    {
                        for (double a = length; a >= 0.0; a -= grid_map_->getResolution())
                        {
                            bool occ = grid_map_->getInflateOccupancy((a / length) * intersection_point + (1 - a / length) * cps_.points.col(j));
                            if (occ || a < grid_map_->getResolution())
                            {
                                if (occ)
                                    a += grid_map_->getResolution();
                                cps_.base_point[j].push_back((a / length) * intersection_point + (1 - a / length) * cps_.points.col(j));
                                cps_.direction[j].push_back((intersection_point - cps_.points.col(j)).normalized());
                                break;
                            }
                        }
                    }
                    else
                    {
                        got_intersection_id = -1;
                    }
                }
            }
            if (got_intersection_id >= 0)
            {
                for (int j = got_intersection_id + 1; j <= segment_ids[i].second; ++j)
                    if (!cps_.flag_temp[j])
                    {
                        cps_.base_point[j].push_back(cps_.base_point[j - 1].back());
                        cps_.direction[j].push_back(cps_.direction[j - 1].back());
                    }
                for (int j = got_intersection_id - 1; j >= segment_ids[i].first; --j)
                    if (!cps_.flag_temp[j])
                    {
                        cps_.base_point[j].push_back(cps_.base_point[j + 1].back());
                        cps_.direction[j].push_back(cps_.direction[j + 1].back());
                    }
            }
            else
            {
                ROS_WARN("Failed to generate direction. It doesn't matter.");
            }
        }
        force_stop_type_ = STOP_FOR_REBOUND;
        return true;
    }
    return false;
}

int BsplineOptimizer::earlyExit(void *func_data, const double *x, const double *g, const double fx, const double xnorm, const double gnorm, const double step, int n, int k, int ls)
{
    BsplineOptimizer *opt = reinterpret_cast<BsplineOptimizer *>(func_data);
    return (opt->force_stop_type_ == STOP_FOR_ERROR || opt->force_stop_type_ == STOP_FOR_REBOUND);
}

double BsplineOptimizer::costFunctionOptimize(void *func_data, const double *x, double *grad, const int n)
{
    BsplineOptimizer *opt = reinterpret_cast<BsplineOptimizer *>(func_data);
    double cost;
    opt->combineCostOptimize(x, grad, cost, n);
    opt->iter_num_ += 1;
    return cost;
}

double BsplineOptimizer::costFunctionRebound(void *func_data, const double *x, double *grad, const int n)
{
    BsplineOptimizer *opt = reinterpret_cast<BsplineOptimizer *>(func_data);
    double cost;
    opt->combineCostRebound(x, grad, cost, n);
    opt->iter_num_ += 1;
    return cost;
}

double BsplineOptimizer::costFunctionRefine(void *func_data, const double *x, double *grad, const int n)
{
    BsplineOptimizer *opt = reinterpret_cast<BsplineOptimizer *>(func_data);
    double cost;
    opt->combineCostRefine(x, grad, cost, n);
    opt->iter_num_ += 1;
    return cost;
}

bool BsplineOptimizer::traj_optimize()
{
    iter_num_ = 0;
    int start_id = order_;
    int end_id = this->cps_.size - order_;
    variable_num_ = 3 * (end_id - start_id);
    double final_cost;
    ros::Time t0 = ros::Time::now(), t1, t2;
    int restart_nums = 0, rebound_times = 0;
    bool flag_force_return, flag_occ, success;
    new_lambda2_ = lambda2_;
    constexpr int MAX_RESART_NUMS_SET = 3;
    do
    {
        min_cost_ = std::numeric_limits<double>::max();
        iter_num_ = 0;
        flag_force_return = false;
        flag_occ = false;
        success = false;
        double q[variable_num_];
        memcpy(q, cps_.points.data() + 3 * start_id, variable_num_ * sizeof(q[0]));
        lbfgs::lbfgs_parameter_t lbfgs_params;
        lbfgs::lbfgs_load_default_parameters(&lbfgs_params);
        lbfgs_params.mem_size = 16;
        lbfgs_params.max_iterations = 200;
        lbfgs_params.g_epsilon = 0.01;
        t1 = ros::Time::now();
        int result = lbfgs::lbfgs_optimize(variable_num_, q, &final_cost, BsplineOptimizer::costFunctionRebound, NULL, BsplineOptimizer::earlyExit, this, &lbfgs_params);
        t2 = ros::Time::now();
        double time_ms = (t2 - t1).toSec() * 1000;
        double total_time_ms = (t2 - t0).toSec() * 1000;
        if (result == lbfgs::LBFGS_CONVERGENCE ||
            result == lbfgs::LBFGSERR_MAXIMUMITERATION ||
            result == lbfgs::LBFGS_ALREADY_MINIMIZED ||
            result == lbfgs::LBFGS_STOP)
        {
            flag_force_return = false;
            UniformBspline traj = UniformBspline(cps_.points, 3, bspline_interval_);
            double tm, tmp;
            traj.getTimeSpan(tm, tmp);
            double t_step = (tmp - tm) / ((traj.evaluateDeBoorT(tmp) - traj.evaluateDeBoorT(tm)).norm() / grid_map_->getResolution());
            for (double t = tm; t < tmp * 2 / 3; t += t_step)
            {
                flag_occ = grid_map_->getInflateOccupancy(traj.evaluateDeBoorT(t));
                if (flag_occ)
                {
                    if (t <= bspline_interval_)
                    {
                        cout << cps_.points.col(1).transpose() << "\n"
                             << cps_.points.col(2).transpose() << "\n"
                             << cps_.points.col(3).transpose() << "\n"
                             << cps_.points.col(4).transpose() << endl;
                        ROS_WARN("First 3 control points in obstacles! return false, t=%f", t);
                        return false;
                    }
                    break;
                }
            }
            if (!flag_occ)
            {
                printf("\033[32miter(+1)=%d,time(ms)=%5.3f,total_t(ms)=%5.3f,cost=%5.3f\n\033[0m", iter_num_, time_ms, total_time_ms, final_cost);
                success = true;
            }
            else
            {
                restart_nums++;
                initControlPoints(cps_.points, false);
                new_lambda2_ *= 2;
                printf("\033[32miter(+1)=%d,time(ms)=%5.3f,keep optimizing\n\033[0m", iter_num_, time_ms);
            }
        }
        else if (result == lbfgs::LBFGSERR_CANCELED)
        {
            flag_force_return = true;
            rebound_times++;
            cout << "iter=" << iter_num_ << ",time(ms)=" << time_ms << ",rebound." << endl;
        }
        else
        {
            ROS_WARN("Solver error. Return = %d, %s. Skip this planning.", result, lbfgs::lbfgs_strerror(result));
        }
    } while ((flag_occ && restart_nums < MAX_RESART_NUMS_SET) ||
             (flag_force_return && force_stop_type_ == STOP_FOR_REBOUND && rebound_times <= 20));
    return success;
}

bool BsplineOptimizer::rebound_optimize()
{
    iter_num_ = 0;
    int start_id = order_;
    int end_id = this->cps_.size - order_;
    variable_num_ = 3 * (end_id - start_id);
    double final_cost;
    ros::Time t0 = ros::Time::now(), t1, t2;
    int restart_nums = 0, rebound_times = 0;
    bool flag_force_return, flag_occ, success;
    new_lambda2_ = lambda2_;
    constexpr int MAX_RESART_NUMS_SET = 3;
    do
    {
        min_cost_ = std::numeric_limits<double>::max();
        iter_num_ = 0;
        flag_force_return = false;
        flag_occ = false;
        success = false;
        double q[variable_num_];
        memcpy(q, cps_.points.data() + 3 * start_id, variable_num_ * sizeof(q[0]));
        lbfgs::lbfgs_parameter_t lbfgs_params;
        lbfgs::lbfgs_load_default_parameters(&lbfgs_params);
        lbfgs_params.mem_size = 16;
        lbfgs_params.max_iterations = 200;
        lbfgs_params.g_epsilon = 0.01;
        t1 = ros::Time::now();
        int result = lbfgs::lbfgs_optimize(variable_num_, q, &final_cost, BsplineOptimizer::costFunctionRebound, NULL, BsplineOptimizer::earlyExit, this, &lbfgs_params);
        t2 = ros::Time::now();
        double time_ms = (t2 - t1).toSec() * 1000;
        double total_time_ms = (t2 - t0).toSec() * 1000;
        if (result == lbfgs::LBFGS_CONVERGENCE ||
            result == lbfgs::LBFGSERR_MAXIMUMITERATION ||
            result == lbfgs::LBFGS_ALREADY_MINIMIZED ||
            result == lbfgs::LBFGS_STOP)
        {
            flag_force_return = false;
            UniformBspline traj = UniformBspline(cps_.points, 3, bspline_interval_);
            double tm, tmp;
            traj.getTimeSpan(tm, tmp);
            double t_step = (tmp - tm) / ((traj.evaluateDeBoorT(tmp) - traj.evaluateDeBoorT(tm)).norm() / grid_map_->getResolution());
            for (double t = tm; t < tmp * 2 / 3; t += t_step)
            {
                flag_occ = grid_map_->getInflateOccupancy(traj.evaluateDeBoorT(t));
                if (flag_occ)
                {
                    if (t <= bspline_interval_)
                    {
                        cout << cps_.points.col(1).transpose() << "\n"
                             << cps_.points.col(2).transpose() << "\n"
                             << cps_.points.col(3).transpose() << "\n"
                             << cps_.points.col(4).transpose() << endl;
                        ROS_WARN("First 3 control points in obstacles! return false, t=%f", t);
                        return false;
                    }
                    break;
                }
            }
            if (!flag_occ)
            {
                printf("\033[32miter(+1)=%d,time(ms)=%5.3f,total_t(ms)=%5.3f,cost=%5.3f\n\033[0m", iter_num_, time_ms, total_time_ms, final_cost);
                success = true;
            }
            else
            {
                restart_nums++;
                initControlPoints(cps_.points, false);
                new_lambda2_ *= 2;
                printf("\033[32miter(+1)=%d,time(ms)=%5.3f,keep optimizing\n\033[0m", iter_num_, time_ms);
            }
        }
        else if (result == lbfgs::LBFGSERR_CANCELED)
        {
            flag_force_return = true;
            rebound_times++;
            cout << "iter=" << iter_num_ << ",time(ms)=" << time_ms << ",rebound." << endl;
        }
        else
        {
            ROS_WARN("Solver error. Return = %d, %s. Skip this planning.", result, lbfgs::lbfgs_strerror(result));
        }
    } while ((flag_occ && restart_nums < MAX_RESART_NUMS_SET) ||
             (flag_force_return && force_stop_type_ == STOP_FOR_REBOUND && rebound_times <= 20));
    return success;
}

bool BsplineOptimizer::refine_optimize()
{
    iter_num_ = 0;
    int start_id = order_;
    int end_id = this->cps_.points.cols() - order_;
    variable_num_ = 3 * (end_id - start_id);
    double q[variable_num_];
    double final_cost;
    memcpy(q, cps_.points.data() + 3 * start_id, variable_num_ * sizeof(q[0]));
    double origin_lambda4 = lambda4_;
    bool flag_safe = true;
    int iter_count = 0;
    do
    {
        lbfgs::lbfgs_parameter_t lbfgs_params;
        lbfgs::lbfgs_load_default_parameters(&lbfgs_params);
        lbfgs_params.mem_size = 16;
        lbfgs_params.max_iterations = 200;
        lbfgs_params.g_epsilon = 0.001;
        int result = lbfgs::lbfgs_optimize(variable_num_, q, &final_cost, BsplineOptimizer::costFunctionRefine, NULL, NULL, this, &lbfgs_params);
        if (result == lbfgs::LBFGS_CONVERGENCE ||
            result == lbfgs::LBFGSERR_MAXIMUMITERATION ||
            result == lbfgs::LBFGS_ALREADY_MINIMIZED ||
            result == lbfgs::LBFGS_STOP)
        {
        }
        else
        {
            ROS_ERROR("Solver error in refining!, return = %d, %s", result, lbfgs::lbfgs_strerror(result));
        }
        UniformBspline traj = UniformBspline(cps_.points, 3, bspline_interval_);
        double tm, tmp;
        traj.getTimeSpan(tm, tmp);
        double t_step = (tmp - tm) / ((traj.evaluateDeBoorT(tmp) - traj.evaluateDeBoorT(tm)).norm() / grid_map_->getResolution());
        for (double t = tm; t < tmp * 2 / 3; t += t_step)
        {
            if (grid_map_->getInflateOccupancy(traj.evaluateDeBoorT(t)))
            {
                Eigen::MatrixXd ref_pts(ref_pts_.size(), 3);
                for (size_t i = 0; i < ref_pts_.size(); i++)
                {
                    ref_pts.row(i) = ref_pts_[i].transpose();
                }
                flag_safe = false;
                break;
            }
        }
        if (!flag_safe)
            lambda4_ *= 2;
        iter_count++;
    } while (!flag_safe && iter_count <= 0);
    lambda4_ = origin_lambda4;
    return flag_safe;
}

void BsplineOptimizer::combineCostOptimize(const double *x, double *grad, double &f_combine, const int n)
{
    memcpy(cps_.points.data() + 3 * order_, x, n * sizeof(x[0]));
    double f_smoothness, f_distance, f_feasibility;
    Eigen::MatrixXd g_smoothness = Eigen::MatrixXd::Zero(3, cps_.size);
    Eigen::MatrixXd g_distance = Eigen::MatrixXd::Zero(3, cps_.size);
    Eigen::MatrixXd g_feasibility = Eigen::MatrixXd::Zero(3, cps_.size);
    calcSmoothnessCost(cps_.points, f_smoothness, g_smoothness);
    calcDistanceCostRebound(cps_.points, f_distance, g_distance, iter_num_, f_smoothness);
    calcFeasibilityCost(cps_.points, f_feasibility, g_feasibility);
    f_combine = lambda1_ * f_smoothness + new_lambda2_ * f_distance + lambda3_ * f_feasibility;
    Eigen::MatrixXd grad_3D = lambda1_ * g_smoothness + new_lambda2_ * g_distance + lambda3_ * g_feasibility;
    memcpy(grad, grad_3D.data() + 3 * order_, n * sizeof(grad[0]));
}

void BsplineOptimizer::combineCostRebound(const double *x, double *grad, double &f_combine, const int n)
{
    memcpy(cps_.points.data() + 3 * order_, x, n * sizeof(x[0]));
    double f_smoothness, f_distance, f_feasibility;
    Eigen::MatrixXd g_smoothness = Eigen::MatrixXd::Zero(3, cps_.size);
    Eigen::MatrixXd g_distance = Eigen::MatrixXd::Zero(3, cps_.size);
    Eigen::MatrixXd g_feasibility = Eigen::MatrixXd::Zero(3, cps_.size);
    calcSmoothnessCost(cps_.points, f_smoothness, g_smoothness);
    calcDistanceCostRebound(cps_.points, f_distance, g_distance, iter_num_, f_smoothness);
    calcFeasibilityCost(cps_.points, f_feasibility, g_feasibility);
    f_combine = lambda1_ * f_smoothness + new_lambda2_ * f_distance + lambda3_ * f_feasibility;
    Eigen::MatrixXd grad_3D = lambda1_ * g_smoothness + new_lambda2_ * g_distance + lambda3_ * g_feasibility;
    memcpy(grad, grad_3D.data() + 3 * order_, n * sizeof(grad[0]));
}

void BsplineOptimizer::combineCostRefine(const double *x, double *grad, double &f_combine, const int n)
{
    memcpy(cps_.points.data() + 3 * order_, x, n * sizeof(x[0]));
    double f_smoothness, f_fitness, f_feasibility;
    Eigen::MatrixXd g_smoothness = Eigen::MatrixXd::Zero(3, cps_.points.cols());
    Eigen::MatrixXd g_fitness = Eigen::MatrixXd::Zero(3, cps_.points.cols());
    Eigen::MatrixXd g_feasibility = Eigen::MatrixXd::Zero(3, cps_.points.cols());
    calcSmoothnessCost(cps_.points, f_smoothness, g_smoothness);
    calcFitnessCost(cps_.points, f_fitness, g_fitness);
    calcFeasibilityCost(cps_.points, f_feasibility, g_feasibility);
    f_combine = lambda1_ * f_smoothness + lambda4_ * f_fitness + lambda3_ * f_feasibility;
    Eigen::MatrixXd grad_3D = lambda1_ * g_smoothness + lambda4_ * g_fitness + lambda3_ * g_feasibility;
    memcpy(grad, grad_3D.data() + 3 * order_, n * sizeof(grad[0]));
}

void BsplineOptimizer::setEnvironment(const GridMap::Ptr &env)
{
    this->grid_map_ = env;
}

void BsplineOptimizer::setParam(ros::NodeHandle &nh)
{
    nh.param("optimization/lambda_smooth", lambda1_, -1.0);
    nh.param("optimization/lambda_collision", lambda2_, -1.0);
    nh.param("optimization/lambda_feasibility", lambda3_, -1.0);
    nh.param("optimization/lambda_fitness", lambda4_, -1.0);
    nh.param("optimization/dist0", dist0_, -1.0);
    nh.param("optimization/max_vel", max_vel_, -1.0);
    nh.param("optimization/max_acc", max_acc_, -1.0);
    nh.param("optimization/order", order_, 3);
}

void BsplineOptimizer::setControlPoints(const Eigen::MatrixXd &points)
{
    cps_.points = points;
}

void BsplineOptimizer::setBsplineInterval(const double &ts)
{
    bspline_interval_ = ts;
}

std::vector<std::vector<Eigen::Vector3d>> BsplineOptimizer::initControlPoints(const Eigen::MatrixXd &init_points, bool flag_first_init /*= true*/)
{
    if (flag_first_init)
    {
        cps_.clearance = dist0_;
        cps_.resize(init_points.cols());
        cps_.points = init_points;
    }
    constexpr int ENOUGH_INTERVAL = 2;
    double step_size = grid_map_->getResolution() / ((init_points.col(0) - init_points.rightCols(1)).norm() / (init_points.cols() - 1)) / 2;
    int in_id = -1, out_id = -1;
    vector<std::pair<int, int>> segment_ids;
    int same_occ_state_times = ENOUGH_INTERVAL + 1;
    bool occ, last_occ = false;
    bool flag_got_start = false, flag_got_end = false, flag_got_end_maybe = false;
    int i_end = (int)init_points.cols() - order_ - ((int)init_points.cols() - 2 * order_) / 3;
    for (int i = order_; i <= i_end; ++i)
    {
        for (double a = 1.0; a >= 0.0; a -= step_size)
        {
            occ = grid_map_->getInflateOccupancy(a * init_points.col(i - 1) + (1 - a) * init_points.col(i));
            if (occ && !last_occ)
            {
                if (same_occ_state_times > ENOUGH_INTERVAL || i == order_)
                {
                    in_id = i - 1;
                    flag_got_start = true;
                }
                same_occ_state_times = 0;
                flag_got_end_maybe = false;
            }
            else if (!occ && last_occ)
            {
                out_id = i;
                flag_got_end_maybe = true;
                same_occ_state_times = 0;
            }
            else
            {
                ++same_occ_state_times;
            }
            if (flag_got_end_maybe && (same_occ_state_times > ENOUGH_INTERVAL || (i == (int)init_points.cols() - order_)))
            {
                flag_got_end_maybe = false;
                flag_got_end = true;
            }
            last_occ = occ;
            if (flag_got_start && flag_got_end)
            {
                flag_got_start = false;
                flag_got_end = false;
                segment_ids.push_back(std::pair<int, int>(in_id, out_id));
            }
        }
    }
    vector<vector<Eigen::Vector3d>> a_star_pathes;
    for (size_t i = 0; i < segment_ids.size(); ++i)
    {
        Eigen::Vector3d in(init_points.col(segment_ids[i].first)), out(init_points.col(segment_ids[i].second));
        if (a_star_->AstarSearch(0.1, in, out))
        {
            a_star_pathes.push_back(a_star_->getPath());
        }
        else
        {
            ROS_ERROR("a star error, force return!");
            return a_star_pathes;
        }
    }
    int id_low_bound, id_up_bound;
    vector<std::pair<int, int>> bounds(segment_ids.size());
    for (size_t i = 0; i < segment_ids.size(); i++)
    {
        if (i == 0)
        {
            id_low_bound = order_;
            if (segment_ids.size() > 1)
            {
                id_up_bound = (int)(((segment_ids[0].second + segment_ids[1].first) - 1.0f) / 2);
            }
            else
            {
                id_up_bound = init_points.cols() - order_ - 1;
            }
        }
        else if (i == segment_ids.size() - 1)
        {
            id_low_bound = (int)(((segment_ids[i].first + segment_ids[i - 1].second) + 1.0f) / 2);
            id_up_bound = init_points.cols() - order_ - 1;
        }
        else
        {
            id_low_bound = (int)(((segment_ids[i].first + segment_ids[i - 1].second) + 1.0f) / 2);
            id_up_bound = (int)(((segment_ids[i].second + segment_ids[i + 1].first) - 1.0f) / 2);
        }
        bounds[i] = std::pair<int, int>(id_low_bound, id_up_bound);
    }
    vector<std::pair<int, int>> final_segment_ids(segment_ids.size());
    constexpr double MINIMUM_PERCENT = 0.0;
    int minimum_points = round(init_points.cols() * MINIMUM_PERCENT);
    int num_points;
    for (size_t i = 0; i < segment_ids.size(); i++)
    {
        num_points = segment_ids[i].second - segment_ids[i].first + 1;
        if (num_points < minimum_points)
        {
            double add_points_each_side = (int)(((minimum_points - num_points) + 1.0f) / 2);
            final_segment_ids[i].first = segment_ids[i].first - add_points_each_side >= bounds[i].first ? segment_ids[i].first - add_points_each_side : bounds[i].first;
            final_segment_ids[i].second = segment_ids[i].second + add_points_each_side <= bounds[i].second ? segment_ids[i].second + add_points_each_side : bounds[i].second;
        }
        else
        {
            final_segment_ids[i].first = segment_ids[i].first;
            final_segment_ids[i].second = segment_ids[i].second;
        }
    }
    for (size_t i = 0; i < segment_ids.size(); i++)
    {
        for (int j = final_segment_ids[i].first; j <= final_segment_ids[i].second; ++j)
            cps_.flag_temp[j] = false;
        int got_intersection_id = -1;
        for (int j = segment_ids[i].first + 1; j < segment_ids[i].second; ++j)
        {
            Eigen::Vector3d ctrl_pts_law(cps_.points.col(j + 1) - cps_.points.col(j - 1)), intersection_point;
            int Astar_id = a_star_pathes[i].size() / 2, last_Astar_id;
            double val = (a_star_pathes[i][Astar_id] - cps_.points.col(j)).dot(ctrl_pts_law), last_val = val;
            while (Astar_id >= 0 && Astar_id < (int)a_star_pathes[i].size())
            {
                last_Astar_id = Astar_id;
                if (val >= 0)
                    --Astar_id;
                else
                    ++Astar_id;
                val = (a_star_pathes[i][Astar_id] - cps_.points.col(j)).dot(ctrl_pts_law);
                if (val * last_val <= 0 && (abs(val) > 0 || abs(last_val) > 0))
                {
                    intersection_point =
                        a_star_pathes[i][Astar_id] +
                        ((a_star_pathes[i][Astar_id] - a_star_pathes[i][last_Astar_id]) *
                         (ctrl_pts_law.dot(cps_.points.col(j) - a_star_pathes[i][Astar_id]) / ctrl_pts_law.dot(a_star_pathes[i][Astar_id] - a_star_pathes[i][last_Astar_id])));
                    got_intersection_id = j;
                    break;
                }
            }
            if (got_intersection_id >= 0)
            {
                cps_.flag_temp[j] = true;
                double length = (intersection_point - cps_.points.col(j)).norm();
                if (length > 1e-5)
                {
                    for (double a = length; a >= 0.0; a -= grid_map_->getResolution())
                    {
                        occ = grid_map_->getInflateOccupancy((a / length) * intersection_point + (1 - a / length) * cps_.points.col(j));
                        if (occ || a < grid_map_->getResolution())
                        {
                            if (occ)
                                a += grid_map_->getResolution();
                            cps_.base_point[j].push_back((a / length) * intersection_point + (1 - a / length) * cps_.points.col(j));
                            cps_.direction[j].push_back((intersection_point - cps_.points.col(j)).normalized());
                            break;
                        }
                    }
                }
            }
        }
        if (segment_ids[i].second - segment_ids[i].first == 1)
        {
            Eigen::Vector3d ctrl_pts_law(cps_.points.col(segment_ids[i].second) - cps_.points.col(segment_ids[i].first)), intersection_point;
            Eigen::Vector3d middle_point = (cps_.points.col(segment_ids[i].second) + cps_.points.col(segment_ids[i].first)) / 2;
            int Astar_id = a_star_pathes[i].size() / 2, last_Astar_id;
            double val = (a_star_pathes[i][Astar_id] - middle_point).dot(ctrl_pts_law), last_val = val;
            while (Astar_id >= 0 && Astar_id < (int)a_star_pathes[i].size())
            {
                last_Astar_id = Astar_id;
                if (val >= 0)
                    --Astar_id;
                else
                    ++Astar_id;
                val = (a_star_pathes[i][Astar_id] - middle_point).dot(ctrl_pts_law);
                if (val * last_val <= 0 && (abs(val) > 0 || abs(last_val) > 0))
                {
                    intersection_point =
                        a_star_pathes[i][Astar_id] +
                        ((a_star_pathes[i][Astar_id] - a_star_pathes[i][last_Astar_id]) *
                         (ctrl_pts_law.dot(middle_point - a_star_pathes[i][Astar_id]) / ctrl_pts_law.dot(a_star_pathes[i][Astar_id] - a_star_pathes[i][last_Astar_id])));
                    if ((intersection_point - middle_point).norm() > 0.01)
                    {
                        cps_.flag_temp[segment_ids[i].first] = true;
                        cps_.base_point[segment_ids[i].first].push_back(cps_.points.col(segment_ids[i].first));
                        cps_.direction[segment_ids[i].first].push_back((intersection_point - middle_point).normalized());
                        got_intersection_id = segment_ids[i].first;
                    }
                    break;
                }
            }
        }
        if (got_intersection_id >= 0)
        {
            for (int j = got_intersection_id + 1; j <= final_segment_ids[i].second; ++j)
                if (!cps_.flag_temp[j])
                {
                    cps_.base_point[j].push_back(cps_.base_point[j - 1].back());
                    cps_.direction[j].push_back(cps_.direction[j - 1].back());
                }
            for (int j = got_intersection_id - 1; j >= final_segment_ids[i].first; --j)
                if (!cps_.flag_temp[j])
                {
                    cps_.base_point[j].push_back(cps_.base_point[j + 1].back());
                    cps_.direction[j].push_back(cps_.direction[j + 1].back());
                }
        }
    }
    return a_star_pathes;
}

bool BsplineOptimizer::BsplineOptimizeTrajRebound(Eigen::MatrixXd &optimal_points, double ts)
{
    setBsplineInterval(ts);
    bool flag_success = rebound_optimize();
    optimal_points = cps_.points;
    return flag_success;
}

bool BsplineOptimizer::BsplineOptimizeTrajRefine(const Eigen::MatrixXd &init_points, const double ts, Eigen::MatrixXd &optimal_points)
{
    setControlPoints(init_points);
    setBsplineInterval(ts);
    bool flag_success = refine_optimize();
    optimal_points = cps_.points;
    return flag_success;
}

bool BsplineOptimizer::BsplineOptimizeTraj(const Eigen::MatrixXd &init_points, const double ts, Eigen::MatrixXd &optimal_points)
{
    setControlPoints(init_points);
    setBsplineInterval(ts);
    bool flag_success = traj_optimize();
    optimal_points = cps_.points;
    return flag_success;
}

double BsplineOptimizer::calculateTrajectoryCost(const Eigen::MatrixXd &ctrl_pts, double &ts, Eigen::Vector3d &local_target_pt)
{
    double distance_cost = 0.0;
    int end_idx = ctrl_pts.cols() - order_;
    double demarcation = cps_.clearance;
    double a = 3 * demarcation, b = -3 * pow(demarcation, 2), c = pow(demarcation, 3);
    for (auto i = order_; i < end_idx; ++i)
    {
        for (size_t j = 0; j < cps_.direction[i].size(); ++j)
        {
            double dist = (cps_.points.col(i) - cps_.base_point[i][j]).dot(cps_.direction[i][j]);
            double dist_err = cps_.clearance - dist;
            if (dist_err < 0)
            {
            }
            else if (dist_err < demarcation)
            {
                distance_cost += pow(dist_err, 3);
            }
            else
            {
                distance_cost += a * dist_err * dist_err + b * dist_err + c;
            }
        }
    }
    double smooth_cost = 0.0;
    Eigen::Vector3d jerk, temp_j;
    for (int i = 0; i < ctrl_pts.cols() - 3; i++)
    {
        jerk = ctrl_pts.col(i + 3) - 3 * ctrl_pts.col(i + 2) + 3 * ctrl_pts.col(i + 1) - ctrl_pts.col(i);
        smooth_cost += jerk.squaredNorm();
    }
    double feasibility_cost = 0.0;
    double ts_inv2 = 1 / ts / ts;
    for (int i = 0; i < ctrl_pts.cols() - 1; i++)
    {
        Eigen::Vector3d vi = (ctrl_pts.col(i + 1) - ctrl_pts.col(i)) / ts;
        for (int j = 0; j < 3; j++)
        {
            if (vi(j) > max_vel_)
            {
                feasibility_cost += pow(vi(j) - max_vel_, 2) * ts_inv2;
            }
            else if (vi(j) < -max_vel_)
            {
                feasibility_cost += pow(vi(j) + max_vel_, 2) * ts_inv2;
            }
        }
    }
    for (int i = 0; i < ctrl_pts.cols() - 2; i++)
    {
        Eigen::Vector3d ai = (ctrl_pts.col(i + 2) - 2 * ctrl_pts.col(i + 1) + ctrl_pts.col(i)) * ts_inv2;
        for (int j = 0; j < 3; j++)
        {
            if (ai(j) > max_acc_)
            {
                feasibility_cost += pow(ai(j) - max_acc_, 2);
            }
            else if (ai(j) < -max_acc_)
            {
                feasibility_cost += pow(ai(j) + max_acc_, 2);
            }
        }
    }
    double target_distance_cost = 0.0;
    for (int i = 0; i < ctrl_pts.cols(); i++)
    {
        Eigen::Vector3d point = ctrl_pts.col(i);
        double dist_to_target = (point - local_target_pt).norm();
        target_distance_cost += dist_to_target * dist_to_target;
    }
    Eigen::Vector3d last_point = ctrl_pts.col(ctrl_pts.cols() - 1);
    double last_point_to_target_cost = (last_point - local_target_pt).norm();
    last_point_to_target_cost *= last_point_to_target_cost;
    double cost = 5 * distance_cost + 4 * smooth_cost + 3 * feasibility_cost + 0.2 * target_distance_cost + 20 * last_point_to_target_cost;
    return cost;
}

vector<double> BsplineOptimizer::calcTargetScore(const vector<Eigen::MatrixXd> &ctrl_pts_sets, const Eigen::Vector3d &target_pt)
{
    size_t num_sets = ctrl_pts_sets.size();
    vector<double> score_sets(num_sets, 0.0);
    vector<double> cost_sets(num_sets, 0.0);
    double sum_cost = 0.0;
    for (size_t i = 0; i < num_sets; ++i)
    {
        const Eigen::MatrixXd &ctrl_pts = ctrl_pts_sets[i];
        Eigen::Vector3d last_point = ctrl_pts.col(ctrl_pts.cols() - 1);
        double cost = (last_point - target_pt).norm();
        sum_cost += cost;
        cost_sets[i] = cost;
    }
    if (sum_cost == 0.0)
    {
        score_sets.assign(num_sets, 1.0);
    }
    else
    {
        for (size_t i = 0; i < num_sets; ++i)
        {
            score_sets[i] = std::exp(-cost_sets[i] / sum_cost);
        }
    }
    return score_sets;
}

vector<double> BsplineOptimizer::calcLengthScore(const vector<Eigen::MatrixXd> &ctrl_pts_sets)
{
    size_t num_sets = ctrl_pts_sets.size();
    vector<double> score_sets(num_sets, 0.0);
    vector<double> cost_sets(num_sets, 0.0);
    double sum_cost = 0.0;
    for (size_t i = 0; i < num_sets; ++i)
    {
        const Eigen::MatrixXd &ctrl_pts = ctrl_pts_sets[i];
        Eigen::Vector3d last_point = ctrl_pts.col(ctrl_pts.cols() - 1);
        Eigen::Vector3d first_point = ctrl_pts.col(0);
        double first_last_length = (first_point - last_point).norm();
        double cost = 0.0;
        for (int j = 0; j < ctrl_pts.cols() - 1; j++)
        {
            cost += (ctrl_pts.col(j) - last_point).norm() / first_last_length;
        }
        sum_cost += cost;
        cost_sets[i] = cost;
    }
    if (sum_cost == 0.0)
    {
        score_sets.assign(num_sets, 1.0);
    }
    else
    {
        for (size_t i = 0; i < num_sets; ++i)
        {
            score_sets[i] = std::exp(-cost_sets[i] / sum_cost);
        }
    }
    return score_sets;
}

vector<double> BsplineOptimizer::calcSpeedScore(const vector<Eigen::MatrixXd> &ctrl_pts_sets, const vector<double> &ts_sets)
{
    size_t num_sets = ctrl_pts_sets.size();
    vector<double> score_sets(num_sets, 0.0);
    vector<double> cost_sets(num_sets, 0.0);
    double sum_cost = 0.0;
    for (size_t i = 0; i < num_sets; ++i)
    {
        double cost = 0.0;
        const Eigen::MatrixXd &ctrl_pts = ctrl_pts_sets[i];
        const double &ts = ts_sets[i];
        double ts_inv = 1 / ts;
        for (int j = 0; j < ctrl_pts.cols() - 1; j++)
        {
            Eigen::Vector3d vel = (ctrl_pts.col(j + 1) - ctrl_pts.col(j)) * ts_inv;
            for (int k = 0; k < 3; k++)
            {
                if (vel[k] <= max_vel_ && vel[k] >= -max_vel_)
                {
                    cost += -pow(vel[k] / max_vel_, 2);
                }
            }
        }
        sum_cost += cost;
        cost_sets[i] = cost;
    }
    if (sum_cost == 0.0)
    {
        score_sets.assign(num_sets, 1.0);
    }
    else
    {
        for (size_t i = 0; i < num_sets; ++i)
        {
            score_sets[i] = std::exp(-cost_sets[i] / sum_cost);
        }
    }
    return score_sets;
}

vector<double> BsplineOptimizer::calcDistanceScore(const vector<Eigen::MatrixXd> &ctrl_pts_sets)
{
    size_t num_sets = ctrl_pts_sets.size();
    vector<double> score_sets(num_sets, 0.0);
    vector<double> cost_sets(num_sets, 0.0);
    double sum_cost = 0.0;
    for (size_t i = 0; i < num_sets; ++i)
    {
        const Eigen::MatrixXd &ctrl_pts = ctrl_pts_sets[i];
        initControlPoints(ctrl_pts, true);
        double cost = 0.0;
        int end_idx = ctrl_pts.cols() - order_;
        double demarcation = cps_.clearance;
        double a = 3 * demarcation, b = -3 * pow(demarcation, 2), c = pow(demarcation, 3);
        for (auto j = order_; j < end_idx; ++j)
        {
            for (size_t k = 0; k < cps_.direction[j].size(); ++k)
            {
                double dist = (cps_.points.col(j) - cps_.base_point[j][k]).dot(cps_.direction[j][k]);
                double dist_err = cps_.clearance - dist;
                if (dist_err < 0)
                {
                }
                else if (dist_err < demarcation)
                {
                    cost += pow(dist_err, 3);
                }
                else
                {
                    cost += a * dist_err * dist_err + b * dist_err + c;
                }
            }
        }
        sum_cost += cost;
        cost_sets[i] = cost;
    }
    if (sum_cost == 0.0)
    {
        score_sets.assign(num_sets, 1.0);
    }
    else
    {
        for (size_t i = 0; i < num_sets; ++i)
        {
            score_sets[i] = std::exp(-cost_sets[i] / sum_cost);
        }
    }
    return score_sets;
}

vector<double> BsplineOptimizer::calcSmoothnessScore(const vector<Eigen::MatrixXd> &ctrl_pts_sets, const vector<double> &ts_sets)
{
    size_t num_sets = ctrl_pts_sets.size();
    vector<double> score_sets(num_sets, 0.0);
    vector<double> cost_sets(num_sets, 0.0);
    double sum_cost = 0.0;
    for (size_t i = 0; i < num_sets; ++i)
    {
        double cost = 0.0;
        const Eigen::MatrixXd &ctrl_pts = ctrl_pts_sets[i];
        const double &ts = ts_sets[i];
        double ts_inv = 1 / ts;
        double ts_inv2 = ts_inv / ts;
        double ts_inv3 = ts_inv2 / ts;
        for (int j = 0; j < ctrl_pts.cols() - 3; j++)
        {
            Eigen::Vector3d jerk = (ctrl_pts.col(j + 3) - 3 * ctrl_pts.col(j + 2) + 3 * ctrl_pts.col(j + 1) - ctrl_pts.col(j)) * ts_inv3;
            cost += jerk.squaredNorm();
        }
        sum_cost += cost;
        cost_sets[i] = cost;
    }
    if (sum_cost == 0.0)
    {
        score_sets.assign(num_sets, 1.0);
    }
    else
    {
        for (size_t i = 0; i < num_sets; ++i)
        {
            score_sets[i] = std::exp(-cost_sets[i] / sum_cost);
        }
    }
    return score_sets;
}

vector<double> BsplineOptimizer::calcFeasibilityScore(const vector<Eigen::MatrixXd> &ctrl_pts_sets, const vector<double> &ts_sets)
{
    size_t num_sets = ctrl_pts_sets.size();
    vector<double> score_sets(num_sets, 0.0);
    vector<double> cost_sets(num_sets, 0.0);
    double sum_cost = 0.0;
    for (size_t i = 0; i < ctrl_pts_sets.size(); ++i)
    {
        double cost = 0.0;
        const Eigen::MatrixXd &ctrl_pts = ctrl_pts_sets[i];
        const double &ts = ts_sets[i];
        double ts_inv = 1 / ts;
        double ts_inv2 = ts_inv / ts;
        for (int j = 0; j < ctrl_pts.cols() - 1; j++)
        {
            Eigen::Vector3d vel = (ctrl_pts.col(j + 1) - ctrl_pts.col(j)) * ts_inv;
            for (int k = 0; k < 3; k++)
            {
                if (vel(k) > max_vel_)
                {
                    cost += pow(vel(k) - max_vel_, 2) / pow(max_vel_, 2);
                }
                else if (vel(k) < -max_vel_)
                {
                    cost += pow(vel(k) + max_vel_, 2) / pow(max_vel_, 2);
                }
            }
        }
        for (int j = 0; j < ctrl_pts.cols() - 2; j++)
        {
            Eigen::Vector3d acc = (ctrl_pts.col(j + 2) - 2 * ctrl_pts.col(j + 1) + ctrl_pts.col(j)) * ts_inv2;
            for (int k = 0; k < 3; k++)
            {
                if (acc(k) > max_acc_)
                {
                    cost += pow(acc(k) - max_acc_, 2) / pow(max_acc_, 2);
                }
                else if (acc(k) < -max_acc_)
                {
                    cost += pow(acc(k) + max_acc_, 2) / pow(max_acc_, 2);
                }
            }
        }
        sum_cost += cost;
        cost_sets[i] = cost;
    }
    if (sum_cost == 0.0)
    {
        score_sets.assign(num_sets, 1.0);
    }
    else
    {
        for (size_t i = 0; i < num_sets; ++i)
        {
            score_sets[i] = std::exp(-cost_sets[i] / sum_cost);
        }
    }
    return score_sets;
}

vector<double> BsplineOptimizer::calcTrajectoryScore(const vector<Eigen::MatrixXd> &ctrl_pts_sets, const vector<double> &ts_sets, Eigen::Vector3d &target_pt,
                                                    double target_weight, double length_weight, double distance_weight, double smoothness_weight, double feasibility_weight, double speed_weight)
{
    vector<double> score_sets(ctrl_pts_sets.size());
    vector<double> target_score_sets = calcTargetScore(ctrl_pts_sets, target_pt);
    vector<double> length_score_sets = calcLengthScore(ctrl_pts_sets);
    vector<double> distance_score_sets = calcDistanceScore(ctrl_pts_sets);
    vector<double> smoothness_score_sets = calcSmoothnessScore(ctrl_pts_sets, ts_sets);
    vector<double> feasibility_score_sets = calcFeasibilityScore(ctrl_pts_sets, ts_sets);
    vector<double> speed_score_sets = calcSpeedScore(ctrl_pts_sets, ts_sets);
    for (size_t i = 0; i < score_sets.size(); ++i)
    {
        score_sets[i] = distance_weight * distance_score_sets[i] + smoothness_weight * smoothness_score_sets[i] + feasibility_weight * feasibility_score_sets[i] +
                        target_weight * target_score_sets[i] + length_weight * length_score_sets[i] + speed_weight * speed_score_sets[i];
    }
    return score_sets;
}
}



























