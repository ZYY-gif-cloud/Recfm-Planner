#ifndef _PLANNER_MANAGER_H_
#define _PLANNER_MANAGER_H_

#include <stdlib.h>
#include <ros/ros.h>
#include <recfm_bspline_opt/bspline_optimizer.h>
#include <recfm_bspline_opt/uniform_bspline.h>
#include <recfm_plan_env/grid_map.h>
#include <recfm_planner/plan_container.hpp>
#include <recfm_traj_utils/planning_visualization.h>
#include <recfm_path_searching/rrt.h>
#include <recfm_path_searching/dyn_a_star.h>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <iostream>
#include <boost/filesystem.hpp>
#include <string>
#include <sstream>
#include <iomanip>
#include <ctime>
#include <sys/stat.h>
#include <pcl/visualization/cloud_viewer.h>
#include <ros/package.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/Image.h>
#include <geometry_msgs/Point.h>
#include <cv_bridge/cv_bridge.h>
#include <Eigen/Dense>

#include "recfm_planner/Planner.h"
#include "recfm_planner/Trajectory.h"

namespace recfm_planner
{
class ReCFMPlannerManager
{
private:
  PlanningVisualization::Ptr visualization_;
  BsplineOptimizer::Ptr bspline_optimizer_rebound_;
  int continous_failures_count_{0};
  RRT::Ptr rrt_;
  AStar::Ptr astar_;

  void updateTrajInfo(const UniformBspline &position_traj, const ros::Time time_now);
  void reparamBspline(UniformBspline &bspline, vector<Eigen::Vector3d> &start_end_derivative, double ratio,
                      Eigen::MatrixXd &ctrl_pts, double &dt, double &time_inc);
  bool refineTrajAlgo(UniformBspline &traj, vector<Eigen::Vector3d> &start_end_derivative, double ratio, double &ts,
                      Eigen::MatrixXd &optimal_control_points);
  bool optimizeTrajAlgo(UniformBspline &traj, vector<Eigen::Vector3d> &start_end_derivative, double ratio, double &ts,
                        Eigen::MatrixXd &optimal_control_points);

  void saveOptimalPathToCSV(UniformBspline &optimal_path, const double &ts, const vector<Eigen::Vector3d> &start_end,
                            const std::string &folder_path);
  void saveInitPathToCSV(const vector<Eigen::Vector3d> &init_path, const double &ts, const vector<Eigen::Vector3d> &start_end,
                         const std::string &folder_path);
  void saveStartEndToCSV(const vector<Eigen::Vector3d> &start_end, const vector<Eigen::Vector3d> &start_end_derivatives,
                         const std::string &folder_path);
  bool saveDeepCloudToCSV(const vector<Eigen::Vector3d> &start_end, const std::string &folder_path);
  std::string createTimeStampFolder(const std::string& save_path);
  std::string getWorkspacePath();

public:
  typedef unique_ptr<ReCFMPlannerManager> Ptr;

  PlanParameters pp_;
  LocalTrajData local_data_;
  GlobalTrajData global_data_;
  GridMap::Ptr grid_map_;
  bool planning_collection_;
  bool planning_optimiaztion_;
  int trajectory_num_;
  ros::ServiceClient planner_client_;
  recfm_planner::Planner planner_srv_;
  ros::Publisher data_disp_pub;

  double distance_weight;
  double target_weight;
  double smoothness_weight;
  double feasibility_weight;
  double length_weight;
  double speed_weight;

  ReCFMPlannerManager();
  ~ReCFMPlannerManager();
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW

  bool reboundReplan(Eigen::Vector3d start_pt, Eigen::Vector3d start_vel, Eigen::Vector3d start_acc, Eigen::Vector3d end_pt,
                     Eigen::Vector3d end_vel, Eigen::Vector3d end_acc, Eigen::Vector3d global_target_pt, bool flag_polyInit,
                     bool flag_randomPolyTraj);
  bool EmergencyStop(Eigen::Vector3d stop_pos);
  bool planGlobalTraj(const Eigen::Vector3d &start_pos, const Eigen::Vector3d &start_vel, const Eigen::Vector3d &start_acc,
                      const Eigen::Vector3d &end_pos, const Eigen::Vector3d &end_vel, const Eigen::Vector3d &end_acc);
  bool planGlobalTrajWaypoints(const Eigen::Vector3d &start_pos, const Eigen::Vector3d &start_vel, const Eigen::Vector3d &start_acc,
                               const std::vector<Eigen::Vector3d> &waypoints, const Eigen::Vector3d &end_vel,
                               const Eigen::Vector3d &end_acc);
  void initPlanModules(ros::NodeHandle &nh, PlanningVisualization::Ptr vis = NULL);
};

} // namespace recfm_planner

#endif
