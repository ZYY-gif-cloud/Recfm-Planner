#include <recfm_traj_utils/planning_visualization.h>

using std::cout;
using std::endl;

PlanningVisualization::PlanningVisualization(ros::NodeHandle &nh)
{
    node = nh;
    goal_point_pub = nh.advertise<visualization_msgs::Marker>("goal_point", 2);
    start_point_pub = nh.advertise<visualization_msgs::Marker>("start_point", 2);
    global_list_pub = nh.advertise<visualization_msgs::Marker>("global_list", 2);
    init_list_pub = nh.advertise<visualization_msgs::Marker>("init_list", 2);
    optimal_list_pub = nh.advertise<visualization_msgs::Marker>("optimal_list", 2);
    a_star_list_pub = nh.advertise<visualization_msgs::Marker>("a_star_list", 20);
    rrt_tree_vertices_pub = nh.advertise<visualization_msgs::Marker>("rrt_tree_vertices", 10);
    rrt_tree_edges_pub = nh.advertise<visualization_msgs::Marker>("rrt_tree_edges", 10);
    degraded_list_pub = nh.advertise<visualization_msgs::Marker>("degraded_list", 2);
    local_goal_pub = nh.advertise<visualization_msgs::Marker>("local_goal_point", 10);
}

void PlanningVisualization::displayMarkerList(ros::Publisher &pub, const vector<Eigen::Vector3d> &list, double scale, Eigen::Vector4d color, int id)
{
    visualization_msgs::Marker sphere, line_strip;
    sphere.header.frame_id = line_strip.header.frame_id = "world";
    sphere.header.stamp = line_strip.header.stamp = ros::Time::now();
    sphere.type = visualization_msgs::Marker::SPHERE_LIST;
    line_strip.type = visualization_msgs::Marker::LINE_STRIP;
    sphere.action = line_strip.action = visualization_msgs::Marker::ADD;
    sphere.id = id;
    line_strip.id = id + 1000;
    sphere.pose.orientation.w = line_strip.pose.orientation.w = 1.0;
    sphere.color.r = line_strip.color.r = color(0);
    sphere.color.g = line_strip.color.g = color(1);
    sphere.color.b = line_strip.color.b = color(2);
    sphere.color.a = line_strip.color.a = color(3) > 1e-5 ? color(3) : 1.0;
    sphere.scale.x = scale;
    sphere.scale.y = scale;
    sphere.scale.z = scale;
    line_strip.scale.x = scale / 2;
    geometry_msgs::Point pt;
    for (int i = 0; i < int(list.size()); i++)
    {
        pt.x = list[i](0); 
        pt.y = list[i](1); 
        pt.z = list[i](2);
        sphere.points.push_back(pt);
        line_strip.points.push_back(pt);
    }
    pub.publish(sphere);
    pub.publish(line_strip);
}


void PlanningVisualization::generatePathDisplayArray(visualization_msgs::MarkerArray &array, const vector<Eigen::Vector3d> &list, double scale, Eigen::Vector4d color, int id)
{
    visualization_msgs::Marker sphere, line_strip;
    sphere.header.frame_id = line_strip.header.frame_id = "map";
    sphere.header.stamp = line_strip.header.stamp = ros::Time::now();
    sphere.type = visualization_msgs::Marker::SPHERE_LIST; 
    line_strip.type = visualization_msgs::Marker::LINE_STRIP;
    sphere.action = line_strip.action = visualization_msgs::Marker::ADD;
    sphere.id = id;
    line_strip.id = id + 1;
    sphere.pose.orientation.w = line_strip.pose.orientation.w = 1.0;
    sphere.color.r = line_strip.color.r = color(0);
    sphere.color.g = line_strip.color.g = color(1);
    sphere.color.b = line_strip.color.b = color(2);
    sphere.color.a = line_strip.color.a = color(3) > 1e-5 ? color(3) : 1.0; 
    sphere.scale.x = scale;
    sphere.scale.y = scale;
    sphere.scale.z = scale;
    line_strip.scale.x = scale / 3;
    geometry_msgs::Point pt;
    for (int i = 0; i < int(list.size()); i++)
    {
        pt.x = list[i](0);
        pt.y = list[i](1);
        pt.z = list[i](2);
        sphere.points.push_back(pt); 
        line_strip.points.push_back(pt); 
    }
    array.markers.push_back(sphere);
    array.markers.push_back(line_strip);
}

void PlanningVisualization::generateArrowDisplayArray(visualization_msgs::MarkerArray &array, const vector<Eigen::Vector3d> &list, double scale, Eigen::Vector4d color, int id)
{
    visualization_msgs::Marker arrow;
    arrow.header.frame_id = "map";
    arrow.header.stamp = ros::Time::now();
    arrow.type = visualization_msgs::Marker::ARROW;
    arrow.action = visualization_msgs::Marker::ADD;
    arrow.color.r = color(0);
    arrow.color.g = color(1);
    arrow.color.b = color(2);
    arrow.color.a = color(3) > 1e-5 ? color(3) : 1.0; 
    arrow.scale.x = scale; 
    arrow.scale.y = 2 * scale; 
    arrow.scale.z = 2 * scale;
    geometry_msgs::Point start, end;
    for (int i = 0; i < int(list.size() / 2); i++)
    {
        start.x = list[2 * i](0);
        start.y = list[2 * i](1);
        start.z = list[2 * i](2);
        end.x = list[2 * i + 1](0);
        end.y = list[2 * i + 1](1);
        end.z = list[2 * i + 1](2);
        arrow.points.clear();
        arrow.points.push_back(start);
        arrow.points.push_back(end);
        arrow.id = i + id * 1000;
        array.markers.push_back(arrow);
    }
}

void PlanningVisualization::displayGoalPoint(Eigen::Vector3d goal_point, Eigen::Vector4d color, const double scale, int id)
{
    visualization_msgs::Marker sphere;
    sphere.header.frame_id = "world";
    sphere.header.stamp = ros::Time::now();
    sphere.type = visualization_msgs::Marker::SPHERE;
    sphere.action = visualization_msgs::Marker::ADD;
    sphere.id = id;
    sphere.pose.orientation.w = 1.0;
    sphere.color.r = color(0);
    sphere.color.g = color(1);
    sphere.color.b = color(2);
    sphere.color.a = color(3);
    sphere.scale.x = scale;
    sphere.scale.y = scale;
    sphere.scale.z = scale;
    sphere.pose.position.x = goal_point(0);
    sphere.pose.position.y = goal_point(1);
    sphere.pose.position.z = goal_point(2);
    goal_point_pub.publish(sphere);
}

void PlanningVisualization::displayStartPoint(Eigen::Vector3d start_point, Eigen::Vector4d color, const double scale, int id)
{
    visualization_msgs::Marker sphere;
    sphere.header.frame_id = "world";
    sphere.header.stamp = ros::Time::now();
    sphere.type = visualization_msgs::Marker::SPHERE;
    sphere.action = visualization_msgs::Marker::ADD;
    sphere.id = id;
    sphere.pose.orientation.w = 1.0;
    sphere.color.r = color(0);
    sphere.color.g = color(1);
    sphere.color.b = color(2);
    sphere.color.a = color(3);
    sphere.scale.x = scale;
    sphere.scale.y = scale;
    sphere.scale.z = scale;
    sphere.pose.position.x = start_point(0);
    sphere.pose.position.y = start_point(1);
    sphere.pose.position.z = start_point(2);
    start_point_pub.publish(sphere);
}

void PlanningVisualization::displayGlobalPathList(vector<Eigen::Vector3d> init_pts, const double scale, int id)
{
    if (global_list_pub.getNumSubscribers() == 0)
    {
        return;
    }
    Eigen::Vector4d color(0, 0.5, 0.5, 1);
    displayMarkerList(global_list_pub, init_pts, scale, color, id);
}

void PlanningVisualization::displayInitPathList(std::vector<std::vector<Eigen::Vector3d>> &init_pts_list, const double scale, int id)
{
    if (init_list_pub.getNumSubscribers() == 0)
    {
        return;
    }
    Eigen::Vector4d color(186.0 / 255.0, 85.0 / 255.0, 211.0 / 255.0, 1.0);
    visualization_msgs::Marker sphere, line_strip;
    sphere.header.frame_id = line_strip.header.frame_id = "world";
    sphere.header.stamp = line_strip.header.stamp = ros::Time::now();
    sphere.type = visualization_msgs::Marker::SPHERE_LIST; 
    line_strip.type = visualization_msgs::Marker::LINE_LIST;
    sphere.action = line_strip.action = visualization_msgs::Marker::ADD;
    sphere.id = id ; line_strip.id = id + 1;
    sphere.pose.orientation.w = line_strip.pose.orientation.w = 1.0;
    sphere.color.r = line_strip.color.r = color(0);
    sphere.color.g = line_strip.color.g = color(1);
    sphere.color.b = line_strip.color.b = color(2);
    sphere.color.a = line_strip.color.a = color(3) > 1e-5 ? color(3) : 1.0;
    sphere.scale.x = sphere.scale.y = sphere.scale.z = scale;
    line_strip.scale.x = line_strip.scale.y = line_strip.scale.z = scale / 2;
    for (const auto& path : init_pts_list)
    {
        for (size_t j = 0; j < path.size(); ++j)
        {
            geometry_msgs::Point pt;
            std::tie(pt.x, pt.y, pt.z) = std::make_tuple(path[j](0), path[j](1), path[j](2));
            sphere.points.push_back(pt);
            if (j > 0)
            {
                geometry_msgs::Point last_pt;
                std::tie(last_pt.x, last_pt.y, last_pt.z) = std::make_tuple(path[j - 1](0), path[j - 1](1), path[j - 1](2));
                line_strip.points.push_back(last_pt); 
                line_strip.points.push_back(pt);
            }
        }
    }
    init_list_pub.publish(sphere);
    init_list_pub.publish(line_strip);
}

void PlanningVisualization::displayLocalGoalPoint(const std::vector<Eigen::Vector3d>& local_goal_points, const double scale, int id)
{
    if (local_goal_pub.getNumSubscribers() == 0)
    {
        return;
    }
    Eigen::Vector4d color(1.0, 0.0, 0.0, 1.0);
    visualization_msgs::Marker sphere;
    sphere.header.frame_id = "world";
    sphere.header.stamp = ros::Time::now();
    sphere.type = visualization_msgs::Marker::SPHERE_LIST; 
    sphere.action = visualization_msgs::Marker::ADD;
    sphere.id = id ;
    sphere.pose.orientation.w = 1.0;
    sphere.color.r  = color(0);
    sphere.color.g  = color(1);
    sphere.color.b  = color(2);
    sphere.color.a  = color(3) > 1e-5 ? color(3) : 1.0; 
    sphere.scale.x = sphere.scale.y = sphere.scale.z = scale;
    for (size_t i = 0; i < local_goal_points.size(); ++i)
    {
        geometry_msgs::Point pt;
        std::tie(pt.x, pt.y, pt.z) = std::make_tuple(local_goal_points[i](0), local_goal_points[i](1), local_goal_points[i](2));
        sphere.points.push_back(pt); 
    }
    local_goal_pub.publish(sphere);
}


void PlanningVisualization::displayDegradedPathList(std::vector<std::vector<Eigen::Vector3d>> &degraded_pts_list, const double scale, int id)
{
    if (degraded_list_pub.getNumSubscribers() == 0)
    {
        return;
    }
    Eigen::Vector4d color(0, 0, 1, 1);
    visualization_msgs::Marker sphere, line_strip;
    sphere.header.frame_id = line_strip.header.frame_id = "world";
    sphere.header.stamp = line_strip.header.stamp = ros::Time::now();
    sphere.type = visualization_msgs::Marker::SPHERE_LIST; 
    line_strip.type = visualization_msgs::Marker::LINE_LIST; 
    sphere.action = line_strip.action = visualization_msgs::Marker::ADD;
    sphere.id = id ; line_strip.id = id + 1;
    sphere.pose.orientation.w = line_strip.pose.orientation.w = 1.0;
    sphere.color.r = line_strip.color.r = color(0);
    sphere.color.g = line_strip.color.g = color(1);
    sphere.color.b = line_strip.color.b = color(2);
    sphere.color.a = line_strip.color.a = color(3) > 1e-5 ? color(3) : 1.0;
    sphere.scale.x = sphere.scale.y = sphere.scale.z = scale;
    line_strip.scale.x = line_strip.scale.y = line_strip.scale.z = scale / 2;
    for (const auto& path : degraded_pts_list)
    {
        for (size_t j = 0; j < path.size(); ++j)
        {
            geometry_msgs::Point pt;
            std::tie(pt.x, pt.y, pt.z) = std::make_tuple(path[j](0), path[j](1), path[j](2));
            sphere.points.push_back(pt); 
            if (j > 0)
            {
                geometry_msgs::Point last_pt;
                std::tie(last_pt.x, last_pt.y, last_pt.z) = std::make_tuple(path[j - 1](0), path[j - 1](1), path[j - 1](2));
                line_strip.points.push_back(last_pt); 
                line_strip.points.push_back(pt); 
            }
        }
    }

    degraded_list_pub.publish(sphere);
    degraded_list_pub.publish(line_strip);
}


void PlanningVisualization::displayOptimalList(Eigen::MatrixXd optimal_pts, int id)
{
    if (optimal_list_pub.getNumSubscribers() == 0)
    {
        return;
    }
    vector<Eigen::Vector3d> list;
    for (int i = 0; i < optimal_pts.cols(); i++)
    {
        Eigen::Vector3d pt = optimal_pts.col(i).transpose();
        list.push_back(pt);
    }
    Eigen::Vector4d color(1, 0, 0, 1);
    displayMarkerList(optimal_list_pub, list, 0.15, color, id);
}

void PlanningVisualization::displayAStarList(std::vector<std::vector<Eigen::Vector3d>> a_star_paths, int id /* = Eigen::Vector4d(0.5,0.5,0,1)*/)
{
    if (a_star_list_pub.getNumSubscribers() == 0)
    {
        return;
    }
    int i = 0; 
    vector<Eigen::Vector3d> list; 
    Eigen::Vector4d color = Eigen::Vector4d(0.5 + ((double)rand() / RAND_MAX / 2), 0.5 + ((double)rand() / RAND_MAX / 2), 0, 1);
    double scale = 0.05 + (double)rand() / RAND_MAX / 10;
    for (auto block : a_star_paths)
    {
        list.clear();
        for (auto pt : block)
        {
            list.push_back(pt);
        }
        displayMarkerList(a_star_list_pub, list, scale, color, id + i);
        i++;
    }
}


void PlanningVisualization::displayArrowList(ros::Publisher &pub, const vector<Eigen::Vector3d> &list, double scale, Eigen::Vector4d color, int id)
{
    visualization_msgs::MarkerArray array;
    pub.publish(array);
    generateArrowDisplayArray(array, list, scale, color, id);
    pub.publish(array);
}

void PlanningVisualization::displayRRTverticesList(const std::vector<Eigen::Vector3d> &vertices, double scale, Eigen::Vector4d color, int id)
{
    visualization_msgs::Marker vertices_marker;
    rrt_tree_vertices_pub.publish(vertices_marker);// 发布一个空的MarkerArray，清空之前显示的箭头
    vertices_marker.header.frame_id = "world";
    vertices_marker.header.stamp = ros::Time::now();
    // vertices_marker.ns = "rrt/vertices";
    vertices_marker.id = 0;
    vertices_marker.type = visualization_msgs::Marker::SPHERE_LIST;
    vertices_marker.action = visualization_msgs::Marker::ADD;
    vertices_marker.pose.orientation.w = 1.0;
    vertices_marker.scale.x = scale;
    vertices_marker.scale.y = scale;
    vertices_marker.scale.z = scale;
    vertices_marker.color.r = color(0);
    vertices_marker.color.g = color(1);
    vertices_marker.color.b = color(2);
    vertices_marker.color.a = color(3) > 1e-5 ? color(3) : 1.0;
    for (size_t i = 0; i < vertices.size(); i++)
    {
      geometry_msgs::Point pt;
      pt.x = vertices[i][0];
      pt.y = vertices[i][1];
      pt.z = vertices[i][2];
      vertices_marker.points.push_back(pt);
    }
    rrt_tree_vertices_pub.publish(vertices_marker);
}


void PlanningVisualization::displayRRTedgesList(const std::vector<std::pair<Eigen::Vector3d, Eigen::Vector3d>> &edges, double scale, Eigen::Vector4d color, int id)
{
    visualization_msgs::Marker edges_marker;
    edges_marker.header.frame_id = "world";
    edges_marker.header.stamp = ros::Time::now();
    // edges_marker.ns = "rrt/edges";
    edges_marker.id = 0;
    edges_marker.type = visualization_msgs::Marker::LINE_LIST;
    edges_marker.action = visualization_msgs::Marker::ADD;
    edges_marker.pose.orientation.w = 1.0;
    edges_marker.scale.x = scale;
    edges_marker.scale.y = scale;
    edges_marker.scale.z = scale;
    edges_marker.color.r = color(0);
    edges_marker.color.g = color(1);
    edges_marker.color.b = color(2);
    edges_marker.color.a = color(3) > 1e-5 ? color(3) : 1.0;
    geometry_msgs::Point start_pt, end_pt;
    for (size_t i = 0; i < edges.size(); i++)
    {
      start_pt.x = edges[i].first[0];
      start_pt.y = edges[i].first[1];
      start_pt.z = edges[i].first[2];
      end_pt.x = edges[i].second[0];
      end_pt.y = edges[i].second[1];
      end_pt.z = edges[i].second[2];
      edges_marker.points.push_back(start_pt);
      edges_marker.points.push_back(end_pt);
    }
    rrt_tree_edges_pub.publish(edges_marker);
}
