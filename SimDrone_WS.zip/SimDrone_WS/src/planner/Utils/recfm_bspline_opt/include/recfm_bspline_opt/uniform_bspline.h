#ifndef _UNIFORM_BSPLINE_H_
#define _UNIFORM_BSPLINE_H_
#include <Eigen/Eigen>
#include <algorithm>
#include <iostream>
using namespace std;
namespace recfm_planner
{
  class UniformBspline
  {
  private:
    Eigen::MatrixXd control_points_;
    int p_, n_, m_;
    Eigen::VectorXd u_;
    double interval_;
    double limit_vel_;
    double limit_acc_;
    double limit_ratio_;
    double feasibility_tolerance_;
    Eigen::MatrixXd getDerivativeControlPoints();
  public:
    UniformBspline() {}
    UniformBspline(const Eigen::MatrixXd &points, const int &order, const double &interval);
    ~UniformBspline();
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
    void setKnot(const Eigen::VectorXd &knot);
    void setUniformBspline(const Eigen::MatrixXd &points, const int &order, const double &interval);
    void setPhysicalLimits(const double &vel, const double &acc, const double &tolerance);
    Eigen::VectorXd getKnot();
    double getInterval();
    Eigen::MatrixXd getControlPoint();
    bool getTimeSpan(double &um, double &um_p);
    double getTimeSum();
    double getLength(const double &res = 0.01);
    double getJerk();
    void getMeanAndMaxVel(double &mean_v, double &max_v);
    void getMeanAndMaxAcc(double &mean_a, double &max_a);
    UniformBspline getDerivative();
    Eigen::VectorXd evaluateDeBoor(const double &u);
    inline Eigen::VectorXd evaluateDeBoorT(const double &t) { return evaluateDeBoor(t + u_(p_)); }
    static void parameterizeToBspline(const double &ts, const vector<Eigen::Vector3d> &point_set, const vector<Eigen::Vector3d> &start_end_derivative, Eigen::MatrixXd &ctrl_pts);
    bool checkFeasibility(double &ratio, bool show = false);
    double calcFeasibilityRatio();
    void lengthenTime(const double &ratio);
  };
} 
#endif
