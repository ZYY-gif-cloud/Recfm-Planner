#ifndef _PLANNING_VISUALIZATION_H_
#define _PLANNING_VISUALIZATION_H_

#include <vector>
#include <stdlib.h>
#include <iostream>
#include <algorithm>
#include <ros/ros.h>
#include <Eigen/Eigen>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include <recfm_traj_utils/polynomial_traj.h>

using std::vector;

class PlanningVisualization
{
private:
  ros::NodeHandle node;
  ros::Publisher start_point_pub;
  ros::Publisher goal_point_pub;
  ros::Publisher global_list_pub;
  ros::Publisher init_list_pub;
  ros::Publisher optimal_list_pub;
  ros::Publisher a_star_list_pub;
  ros::Publisher guide_vector_pub;
  ros::Publisher intermediate_state_pub;
  ros::Publisher rrt_tree_vertices_pub;
  ros::Publisher rrt_tree_edges_pub;
  ros::Publisher degraded_list_pub;
  ros::Publisher local_goal_pub;

public:
  PlanningVisualization(/* args */) {}
  ~PlanningVisualization() {}
  PlanningVisualization(ros::NodeHandle &nh);

  typedef std::shared_ptr<PlanningVisualization> Ptr;

  void displayMarkerList(ros::Publisher &pub, const vector<Eigen::Vector3d> &list, double scale, Eigen::Vector4d color, int id);
  void generatePathDisplayArray(visualization_msgs::MarkerArray &array, const vector<Eigen::Vector3d> &list, double scale, Eigen::Vector4d color, int id);
  void generateArrowDisplayArray(visualization_msgs::MarkerArray &array, const vector<Eigen::Vector3d> &list, double scale, Eigen::Vector4d color, int id);
  void displayGoalPoint(Eigen::Vector3d goal_point, Eigen::Vector4d color, const double scale, int id);
  void displayStartPoint(Eigen::Vector3d start_point, Eigen::Vector4d color, const double scale, int id);

  void displayGlobalPathList(vector<Eigen::Vector3d> global_pts, const double scale, int id);
  void displayInitPathList(std::vector<std::vector<Eigen::Vector3d>> &init_pts_list, const double scale, int id);
  void displayOptimalList(Eigen::MatrixXd optimal_pts, int id);
  void displayAStarList(std::vector<std::vector<Eigen::Vector3d>> a_star_paths, int id);
  void displayArrowList(ros::Publisher &pub, const vector<Eigen::Vector3d> &list, double scale, Eigen::Vector4d color, int id);
  void displayRRTverticesList(const std::vector<Eigen::Vector3d> &vertices, double scale, Eigen::Vector4d color, int id);
  void displayRRTedgesList(const std::vector<std::pair<Eigen::Vector3d, Eigen::Vector3d>> &edges, double scale, Eigen::Vector4d color, int id);
  void displayDegradedPathList(std::vector<std::vector<Eigen::Vector3d>> &degraded_pts_list, const double scale, int id);
  void displayLocalGoalPoint(const std::vector<Eigen::Vector3d>& local_goal_points, const double scale, int id);
};

#endif
