cmake_minimum_required(VERSION 2.8.3)
project(recfm_path_searching)
set(CMAKE_BUILD_TYPE "Release")
ADD_COMPILE_OPTIONS(-std=c++11)
ADD_COMPILE_OPTIONS(-std=c++14)
set(CMAKE_CXX_FLAGS_RELEASE "-O3 -Wall -g")
find_package(Eigen3 REQUIRED)
find_package(PCL 1.7 REQUIRED)
find_package(catkin REQUIRED COMPONENTS
  roscpp          
  rospy        
  std_msgs        
  visualization_msgs
  recfm_plan_env      
  cv_bridge    
)
catkin_package(
 INCLUDE_DIRS include  
 LIBRARIES recfm_path_searching 
 CATKIN_DEPENDS recfm_plan_env 
)
include_directories( 
    SYSTEM   
    include 
    ${catkin_INCLUDE_DIRS}  
    ${Eigen3_INCLUDE_DIRS} 
    ${PCL_INCLUDE_DIRS}    
)
add_library(recfm_path_searching src/dyn_a_star.cpp src/kdtree.cpp src/rrt.cpp)
target_link_libraries(recfm_path_searching ${catkin_LIBRARIES} ${PCL_LIBRARIES} ${Eigen3_LIBRARIES})
